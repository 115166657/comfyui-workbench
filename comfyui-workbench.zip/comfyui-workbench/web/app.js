'use strict';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const gb = (n) => (n == null ? '未知' : n + ' GB');

const STEPS = ['环境自检', '你的配置', '方案', '插件', '导入与 Agent'];

const state = { boot: null, profile: null, plan: null, markdown: '', step: 0 };

async function api(path, body) {
  const r = await fetch(path, {
    method: body ? 'POST' : 'GET',
    headers: body ? { 'content-type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const j = await r.json().catch(() => ({ ok: false, error: '响应不是 JSON' }));
  if (!r.ok || j.ok === false) throw new Error(j.error || `HTTP ${r.status}`);
  return j;
}

// ---------------- 步骤导航 ----------------
/** 步骤可以深链（#step-3）。刷新不丢进度，也方便把某一步直接发给别人。 */
function hashStep() {
  const m = /^#step-(\d+)$/.exec(location.hash || '');
  if (!m) return null;
  return Math.max(0, Math.min(STEPS.length - 1, Number(m[1]) - 1));
}

function renderSteps() {
  $('#steps').innerHTML = STEPS.map(
    (s, i) => `<button data-go="${i}" class="${i === state.step ? 'on' : i < state.step ? 'done' : ''}">${i + 1}. ${s}</button>`
  ).join('');
}

function go(i) {
  i = Math.max(0, Math.min(STEPS.length - 1, i));
  // 方案还没算出来就不许跳到第 3 步往后 —— 那几页没有数据可渲染
  if (i >= 2 && !state.plan) i = Math.min(1, i);
  state.step = i;
  if (location.hash !== `#step-${i + 1}`) history.replaceState(null, '', `#step-${i + 1}`);
  $$('#main .card').forEach((c) => c.classList.toggle('hidden', Number(c.dataset.step) !== i));
  renderSteps();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ---------------- 第 1 步：环境 ----------------
function renderProbe(env) {
  const rows = [];
  const put = (k, v, bad) => rows.push(`<dt>${k}</dt><dd class="${bad ? 'bad' : ''}">${v}</dd>`);

  put('操作系统', `${esc(env.os.platform)} / ${esc(env.os.release)} / ${esc(env.os.arch)}`);
  put('CPU', env.cpu.model ? `${esc(env.cpu.model)}（${env.cpu.cores} 线程）` : '探测不到');
  put('内存', `${gb(env.ram.totalGB)} 总量，当前可用 ${gb(env.ram.freeGB)}`);
  if (env.gpu) {
    put('显卡', `${esc(env.gpu.name)} · 显存 ${gb(env.gpu.vramTotalGB)}（空闲 ${gb(env.gpu.vramFreeGB)}）· 驱动 ${esc(env.gpu.driver)}`);
  } else {
    put('显卡', `未能通过 nvidia-smi 读取${env.gpuNames ? '：' + esc(env.gpuNames.join(' / ')) : ''} —— 请在下一步手填`, true);
  }
  put('ComfyUI', env.comfy ? `${esc(env.comfy.path)}（${env.comfy.source}）` : '未在常见位置找到 —— 请在下面手填', !env.comfy);
  put('ComfyUI 服务', env.comfyAlive.alive ? `正在运行（:${env.comfyAlive.port}）` : `未运行（:${env.comfyAlive.port}）—— 不影响配置，导入工作流前启动它`);
  const disks = Object.entries(env.disks || {});
  put('磁盘剩余', disks.length ? disks.map(([d, f]) => `${d} ${gb(f)}`).join(' · ') : '读取失败');
  put('Node', esc(env.node));

  $('#probeBox').innerHTML = `<dl style="display:contents">${rows.join('')}</dl>`;

  const path = state.boot.savedProfile?.comfyPath || env.comfy?.path || '';
  $('#comfyPath').value = path;
  $('#installPath').value = path;
  $('#comfyHint').textContent = env.comfy
    ? '已自动填入探测到的路径，如果不对请改。'
    : '填入含 main.py 的那一层，例如 D:\\ComfyUI\\ComfyUI。';
}

// ---------------- 第 2 步：配置 ----------------
function renderGoals() {
  $('#goals').innerHTML = state.boot.goals
    .map((g) => `<div class="goal" data-goal="${g.id}"><div class="t">${esc(g.label)}</div><div class="d">${esc(g.hint)}</div></div>`)
    .join('');
  $$('#goals .goal').forEach((el) =>
    el.addEventListener('click', () => {
      const on = el.classList.toggle('on');
      el.dataset.on = on ? '1' : '';
    })
  );
  // 默认选中「图片生成」：它是验证链路通不通的最小闭环
  const first = $('#goals .goal[data-goal="image"]');
  if (first) { first.classList.add('on'); first.dataset.on = '1'; }
}

function collectProfile() {
  return {
    gpuName: $('#gpuName').value.trim() || null,
    vramGB: Number($('#vramGB').value) || 0,
    ramGB: Number($('#ramGB').value) || 0,
    diskFreeGB: $('#diskFreeGB').value === '' ? null : Number($('#diskFreeGB').value),
    hasNvidia: $('#hasNvidia').checked,
    includeR18: $('#includeR18').checked,
    goals: $$('#goals .goal[data-on="1"]').map((e) => e.dataset.goal),
    comfyPath: $('#installPath').value.trim() || $('#comfyPath').value.trim() || null,
    os: state.boot.env.os.platform,
    arch: state.boot.env.os.arch,
    cpu: state.boot.env.cpu.model,
  };
}

// ---------------- 第 3 步：方案 ----------------
function modelTable(list) {
  if (!list.length) return '<p class="muted">（无）</p>';
  return `<table><tr><th>文件名</th><th>放到</th><th>体积</th><th>用途</th></tr>${list
    .map((m) => {
      const size = m.sizeGB != null ? `${m.sizeGB} GB` : m.sizeGBEst != null ? `约 ${m.sizeGBEst} GB<sup>*</sup>` : '<span class="muted">未知</span>';
      const dir = m.dir ? `models/${esc(m.dir)}/` : '<span class="muted">见说明</span>';
      return `<tr class="${m.r18 ? 'r18' : ''}"><td><code>${esc(m.name)}</code>${m.pluginDep ? `<div class="muted">需 ${esc(m.pluginDep)}</div>` : ''}</td><td class="n">${dir}</td><td class="n">${size}</td><td>${esc(m.role || '')}${m.note ? `<div class="muted">${esc(m.note)}</div>` : ''}</td></tr>`;
    })
    .join('')}</table>`;
}

function renderPlan(plan) {
  const p = [];
  p.push(`<div class="tier"><div class="id">档位 ${esc(plan.tier.id)}</div><div class="nm">${esc(plan.tier.name)}</div><div class="sum">${esc(plan.tier.summary)}</div>`);
  p.push('<div class="kv">');
  p.push(`<div>必装权重<b>${plan.models.required.length} 个 / ${plan.totals.requiredGB} GB</b></div>`);
  p.push(`<div>推荐权重<b>${plan.models.recommended.length} 个 / ${plan.totals.recommendedGB} GB</b></div>`);
  if (plan.totals.r18GB) p.push(`<div>18+ 内容<b>${plan.models.r18.length} 个 / ${plan.totals.r18GB} GB</b></div>`);
  p.push(`<div>要装的插件<b>${plan.plugins.required.length + plan.plugins.recommended.length} 个</b></div>`);
  p.push(`<div>要导入的工作流<b>${plan.workflows.required.length} 份</b></div>`);
  p.push('</div></div>');

  if (plan.videoEnvelope) {
    const v = plan.videoEnvelope;
    p.push(`<div class="note ok"><b>这台机器上的视频参数上限</b>（${esc(v.basis)}）：分辨率 ≤ ${v.maxMegapixels} MP、时长 ≤ ${v.maxSeconds} 秒、步数 ${v.recommendedSteps}。${v.rule ? '<br>' + esc(v.rule) : ''}${v.wallSecondsPerClip ? `<br>参考耗时：单条约 ${v.wallSecondsPerClip} 秒。` : ''}</div>`);
  }
  if (plan.warnings?.length) {
    p.push(`<div class="note"><b>需要你知道的硬约束</b><ul>${plan.warnings.map((w) => `<li>${esc(w)}</li>`).join('')}</ul></div>`);
  }
  if (plan.nonNvidia) {
    p.push(`<div class="note bad"><b>没有 NVIDIA 显卡</b><br>${esc(plan.nonNvidia.note)}<ul>${plan.nonNvidia.checklist.map((c) => `<li>${esc(c)}</li>`).join('')}</ul></div>`);
  }

  p.push('<h2>要导入的工作流</h2>');
  p.push(
    `<table><tr><th>文件</th><th>用途</th><th>引用权重</th><th>体积</th></tr>${plan.workflows.required
      .map((w) => `<tr><td><code>${esc(w.file)}</code><div class="muted">${esc(w.title)}</div></td><td>${esc(w.purpose || '')}</td><td class="n">${w.modelCount} 个</td><td class="n">${w.hasUnknownSizes ? '含未知' : w.totalGB + ' GB'}</td></tr>`)
      .join('')}</table>`
  );
  if (plan.workflows.optional.length) {
    p.push('<p class="muted">可选（档位够但没有塞进必装）：</p><table><tr><th>文件</th><th>要求档位</th><th>体积</th></tr>');
    p.push(plan.workflows.optional.map((w) => `<tr><td><code>${esc(w.file)}</code> ${esc(w.title)}</td><td class="n">${esc(w.minTier)}</td><td class="n">${w.totalGB} GB</td></tr>`).join(''));
    p.push('</table>');
  }
  if (plan.workflows.blocked.length) {
    p.push('<p class="muted">这台机器跑不了，已从清单里剔除：</p><ul class="muted">');
    p.push(plan.workflows.blocked.map((w) => `<li><code>${esc(w.file)}</code> —— ${esc(w.reason)}</li>`).join(''));
    p.push('</ul>');
  }

  p.push(`<h2>必装权重（${plan.totals.requiredGB} GB）</h2>`);
  p.push(modelTable(plan.models.required));
  if (plan.models.recommended.length) {
    p.push(`<h2>推荐权重（${plan.totals.recommendedGB} GB，可后补）</h2>`);
    p.push(modelTable(plan.models.recommended));
  }
  if (plan.models.r18.length) {
    p.push(`<h2><span class="tag r18">18+</span>成人内容相关（${plan.totals.r18GB} GB）</h2>`);
    p.push('<p class="muted">你显式勾选了才会出现在这里。这些是社区 LoRA，来源需要你自己确认合法且自愿再下。</p>');
    p.push(modelTable(plan.models.r18));
  }
  if (plan.models.alternatives.length) {
    p.push(`<h2>同槽位备选（先别下，共 ${plan.totals.savedByVariantDedupGB} GB）</h2>`);
    p.push(
      '<p class="muted">这些文件也出现在你要导入的图里，但它们和上面已选的是<b>同一个槽位的互斥变体</b> —— ' +
        '工作流作者为了兼容不同显存，把好几套权重都画进了同一份图。工作台已经按你的档位选好一套，这些先不要下载。</p>'
    );
    p.push('<table><tr><th>文件</th><th>体积</th><th>为什么被排除</th></tr>');
    p.push(
      plan.models.alternatives
        .map((a) => `<tr><td>${a.files.map((f) => `<code>${esc(f)}</code>`).join('<br>')}</td><td class="n">${a.totalGB} GB</td><td>${esc(a.reason)}</td></tr>`)
        .join('')
    );
    p.push('</table>');
  }
  if (plan.totals.unknownSizeCount) {
    p.push(`<p class="muted"><sup>*</sup>标「约」的是按结构推算的估算值，不是实测；另有 ${plan.totals.unknownSizeCount} 个文件体积未知，以实际下载为准。</p>`);
  }
  if (plan.uncoveredNodeTypes?.length) {
    p.push(`<h2>暂未被插件清单覆盖的节点</h2><p class="muted">这些节点类型没有匹配到已知插件。多数是整合包里的零散节点，导入工作流后看红框即可确认。</p>`);
    p.push(`<div class="pl"><div class="nodes">${plan.uncoveredNodeTypes.map((u) => `<code>${esc(u.nodeType)}</code>`).join(' ')}</div></div>`);
  }

  $('#planBox').innerHTML = p.join('');
}

// ---------------- 第 4 步：插件 ----------------
function pluginCard(pl) {
  const repo = pl.repo
    ? `<code>git clone ${esc(pl.repo)}</code>`
    : `<div class="cmd wrap"># 仓库地址未核实 —— 让 agent 先搜：${esc(pl.searchHint || pl.id)}</div>`;
  const pip = (pl.pip || []).length ? `<div class="cmd">pip install ${esc((pl.pip || []).join(' '))}</div>` : '';
  const tags = [
    pl.confidence === 'high' ? '<span class="tag ok">地址可靠</span>' : '<span class="tag warn">需你搜索</span>',
    pl.matchedCount ? `<span class="tag">覆盖本机图 ${pl.matchedCount} 个节点</span>` : '',
  ].join('');
  return `<div class="pl"><div class="hd"><b>${esc(pl.id)}</b>${tags}</div>
    <p class="why">${esc(pl.why)}</p>
    <div class="cmd">${repo}</div>${pip}
    ${pl.note ? `<p class="why">⚠️ ${esc(pl.note)}</p>` : ''}
    <div class="nodes">提供节点：${(pl.matchedNodes || []).map((n) => esc(n)).join('、') || '（见说明）'}</div></div>`;
}

function renderPlugins(plan) {
  const out = [];
  const sec = (title, list, note) => {
    if (!list.length) return;
    out.push(`<h2>${title}（${list.length}）</h2>`);
    if (note) out.push(`<p class="lead">${note}</p>`);
    out.push(list.map(pluginCard).join(''));
  };
  sec('必装', plan.plugins.required, '少了这些，你要跑的工作流会一屏红框。');
  sec('推荐', plan.plugins.recommended);
  sec('可选', plan.plugins.optional, '只有用到对应功能才需要。');
  if (!out.length) out.push('<p class="muted">按你选的配置与目标，没有额外插件需求。</p>');
  $('#pluginBox').innerHTML = out.join('');
}

// ---------------- 第 5 步：导入与提示词 ----------------
async function doInstall(dryRun) {
  const btn = dryRun ? $('#dryRun') : $('#doInstall');
  btn.disabled = true;
  $('#installOut').textContent = dryRun ? '试算中…' : '复制中…';
  try {
    const j = await api('/api/install-workflows', {
      comfyPath: $('#installPath').value.trim(),
      overwrite: $('#overwrite').checked,
      dryRun,
      includeR18: state.profile?.includeR18 || false,
    });
    const lines = [];
    lines.push(`目标目录：${j.destDir}`);
    lines.push(`${dryRun ? '将复制' : '已复制'} ${j.installed.length} 份：`);
    for (const f of j.installed) lines.push(`  ✓ ${f.file}（${(f.bytes / 1024).toFixed(0)} KB）${f.dryRun ? ' [试算]' : ''}`);
    if (j.skipped.length) { lines.push(`跳过 ${j.skipped.length} 份：`); for (const s of j.skipped) lines.push(`  – ${s.file}：${s.reason}`); }
    if (j.missing?.length) { lines.push(`源文件缺失：${j.missing.join(', ')}`); }
    if (j.errors?.length) { lines.push(`失败：`); for (const e of j.errors) lines.push(`  ✗ ${e.file}：${e.error}`); }
    $('#installOut').textContent = lines.join('\n');
  } catch (e) {
    $('#installOut').textContent = '✗ ' + e.message;
  } finally {
    btn.disabled = false;
  }
}

// ---------------- 主流程 ----------------
async function makePlan(jumpTo = null) {
  const profile = collectProfile();
  if (!profile.vramGB || !profile.ramGB) {
    alert('显存和内存都要填。填错会让整套推荐错位，所以不留默认值。');
    return;
  }
  if (!profile.goals.length) {
    alert('至少选一个目标。');
    return;
  }
  const btn = $('#makePlan');
  btn.disabled = true;
  btn.textContent = '计算中…';
  try {
    const { plan } = await api('/api/plan', profile);
    const { markdown } = await api('/api/agent-prompt', { profile });
    state.profile = profile;
    state.plan = plan;
    state.markdown = markdown;
    renderPlan(plan);
    renderPlugins(plan);
    $('#promptBox').value = markdown;
    $('#promptStats').textContent = `${markdown.length} 字符 · 含 ${plan.models.required.length} 个必装权重的完整来源说明`;
    const want = jumpTo ?? hashStep();
    go(want != null && want >= 2 ? want : 2);
    api('/api/profile', profile).catch(() => {});
  } catch (e) {
    alert('生成方案失败：' + e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = '生成方案';
  }
}

function bind() {
  $$('#main [data-next]').forEach((b) => b.addEventListener('click', () => go(state.step + 1)));
  $$('#main [data-prev]').forEach((b) => b.addEventListener('click', () => go(state.step - 1)));
  $('#steps').addEventListener('click', (e) => {
    const b = e.target.closest('[data-go]');
    if (b) go(Number(b.dataset.go));
  });
  $('#reprobe').addEventListener('click', () => boot(true));
  $('#makePlan').addEventListener('click', makePlan);
  $('#dryRun').addEventListener('click', () => doInstall(true));
  $('#doInstall').addEventListener('click', () => doInstall(false));
  $('#copyPrompt').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(state.markdown);
      $('#copyPrompt').textContent = '已复制 ✓';
    } catch {
      $('#promptBox').select();
      document.execCommand('copy');
      $('#copyPrompt').textContent = '已复制 ✓';
    }
    setTimeout(() => ($('#copyPrompt').textContent = '复制提示词'), 1600);
  });
  $('#downloadPrompt').addEventListener('click', () => {
    const blob = new Blob([state.markdown], { type: 'text/markdown;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'comfyui-安装提示词.md';
    a.click();
    URL.revokeObjectURL(a.href);
  });
}

async function boot(reprobe = false) {
  $('#probeBox').textContent = '正在探测…';
  try {
    const j = await api('/api/bootstrap' + (reprobe ? '?t=' + Date.now() : ''));
    state.boot = j;
    renderProbe(j.env);
    renderGoals();

    const sp = j.savedProfile;
    if (sp) {
      $('#gpuName').value = sp.gpuName || j.env.gpu?.name || '';
      $('#vramGB').value = sp.vramGB || j.env.gpu?.vramTotalGB || '';
      $('#ramGB').value = sp.ramGB || j.env.ram.totalGB || '';
      $('#diskFreeGB').value = sp.diskFreeGB ?? '';
      $('#includeR18').checked = !!sp.includeR18;
      $('#hasNvidia').checked = sp.hasNvidia !== false;
      if (sp.goals?.length) {
        $$('#goals .goal').forEach((el) => {
          const on = sp.goals.includes(el.dataset.goal);
          el.classList.toggle('on', on);
          el.dataset.on = on ? '1' : '';
        });
      }
    } else {
      $('#gpuName').value = j.env.gpu?.name || '';
      $('#vramGB').value = j.env.gpu?.vramTotalGB || '';
      $('#ramGB').value = j.env.ram.totalGB || '';
      const first = Object.values(j.env.disks || {})[0];
      if (first != null) $('#diskFreeGB').value = first;
      $('#hasNvidia').checked = j.env.hasNvidia;
    }

    $('#footInfo').textContent = `仓库内 ${j.counts.uiWorkflows} 份可用工作流（另有 ${j.counts.workflows - j.counts.uiWorkflows} 份 API 图）· ${j.counts.models} 个权重引用 · ${j.counts.plugins} 个插件条目 · 全部数据来自本仓库的工作流 JSON`;

    // 先把深链目标读出来 —— go() 会改写 location.hash，在那之后再读就拿不到原始意图了
    const want = hashStep();
    go(want ?? 0);

    // 深链到第 2 步往后 = 用户明确想看方案。已经配置过就直接算给他，不必再点一遍。
    if (want != null && want >= 2 && (sp?.vramGB || j.env.gpu)) makePlan(want);
  } catch (e) {
    $('#probeBox').innerHTML = `<div class="err">探测失败：${esc(e.message)}</div>`;
  }
}

bind();
boot();

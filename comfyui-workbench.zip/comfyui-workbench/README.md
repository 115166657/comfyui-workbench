# ComfyUI 工作台 · 首次配置向导

**装上 → 打开 → 填显卡和内存 → 拿到一份「你这台机器该下哪些模型、装哪些插件、导入哪几份工作流」的清单，
外加一段可以直接丢给你的 AI Agent 去执行的安装提示词。**

零依赖（只用 Node 内置模块），不需要 `npm install`，不联网上传任何东西。

---

## 它解决什么问题

从别人手里拿到一整套 ComfyUI 工作流，真正的痛苦不在跑图，在于**前两个小时**：

- 打开图，一屏红框 —— 不知道缺的是哪个插件；
- 缺 20 个模型文件，一共 100 多 GB，不知道哪几个是**真的必须**的；
- 同一份图里写着 int8、NVFP4、GGUF **三套互斥权重**（作者为了兼容全写进去了），照单全下就是 142 GB；
- 目录名差一个字，模型下好了但在下拉框里选不到；
- 大模型权重放错了盘，`extra_model_paths.yaml` 明明配了却读不到。

这个工作台把这几件事一次性算清楚。它的做法是**不去猜**：

> 清单里的所有权重文件名，都是从 `workflows/` 里那些工作流 JSON **扫出来的真实引用**，
> 不是手抄的模型表。往仓库里加一份新图，清单会自动跟着变。

---

## 30 秒上手

需要 **Node.js 18 或更高版本**（[下载](https://nodejs.org/)）。除此之外什么都不用装。

```bash
git clone <本仓库地址>
cd comfyui-workbench
```

- **Windows**：双击 `启动工作台.cmd`
- **macOS / Linux**：`./start.sh`
- **任意平台命令行**：`node server/server.mjs`

浏览器会自动打开 `http://127.0.0.1:8030`（端口被占就自动往后顺延）。跟着五步走完即可。

不想开浏览器也行，命令行一套到底：

```bash
node tools/cli.mjs probe                              # 探测本机硬件
node tools/cli.mjs plan  --vram 8 --ram 16 --goals video
node tools/cli.mjs prompt --vram 8 --ram 16 --goals video --out 安装提示词.md
node tools/cli.mjs install --comfy "D:\ComfyUI\ComfyUI" --dry    # 先试算
```

---

## 它做什么 / 它不做什么

**做：**

| 能力 | 说明 |
|---|---|
| 硬件探测 | 显卡与显存走 `nvidia-smi`，内存/CPU 走 Node `os`，ComfyUI 路径扫常见位置，顺带看 ComfyUI 有没有在跑 |
| 档位判定 | 按显存分档，再用内存做硬门槛往下压 |
| 权重清单 | 「你想跑的目标工作流 → 图里真实引用的文件」，并按同槽位互斥变体去重 |
| 插件清单 | 从工作流用到的**节点类型**反推需要哪些 custom_nodes；地址没核对过的明确标「需你搜索」 |
| 工作流导入 | 把 `workflows/` 复制进 `<ComfyUI>/user/default/workflows/`，**默认不覆盖同名文件** |
| Agent 提示词 | 生成一段含环境事实、精确文件名、目标目录、验证方法、禁止事项的提示词，交给用户自己的 agent |

**不做（刻意的）：**

- ❌ **不下载任何模型。** 它只告诉你下什么、放哪里。
- ❌ **不安装任何插件。**
- ❌ **不改你的 ComfyUI 配置**，不碰 `extra_model_paths.yaml`，不碰已有文件。
- ❌ **不联网**（除了读本机的 ComfyUI `/system_stats`）。你的配置只写在本机 `data/profile.json`。

> 为什么不自带下载器？模型来源里有一半以上是社区发布（Civitai、夸克网盘、HF 社区量化版），
> 仓库地址会变、会被删、会有多个同名不同版的。与其在代码里写死一堆会过期的直链，
> 不如把「搜索 + 核对 + 重试」这一步交给一个能联网、能试错的 agent —— 也就是你自己的那个。
> 所以这个工作台的最终产物是**一段提示词**，不是自动下载脚本。

---

## 工作原理

```
workflows/*.json  ──┐
                    ├─→ tools/scan-workflows.mjs ─→ 真实引用的权重 + 节点类型
catalog/*.meta.json ┘         （人工注记：体积/来源/档位/变体）      │
                                                                    ▼
                          tools/build-catalog.mjs ──→ catalog/*.json（双向校验，缺一个就报错）
                                                                    │
                      硬件探测 ─→ 档位判定 ─→ server/lib/plan.mjs ──┤
                                                                    ▼
                                            server/lib/agent-prompt.mjs ─→ 给 Agent 的提示词
```

关键的一步在 `build-catalog.mjs`：它做**双向校验** ——
扫到的权重必须有注记，注记的权重必须扫得到，工作流文件与磁盘文件必须一一对应。
任一条对不上就非零退出。这样「清单」和「工作流」不可能悄悄漂移。

---

## 硬件档位

分档以**显存**为主、**内存**为硬门槛。

| 档位 | 显存 | 内存 | 判断 |
|---|---|---|---|
| `t0` | < 6 GB / 非 N 卡 | — | 不建议本地跑主链路，给云端与轻量替代方案 |
| `t1` | 6 ~ 9 GB | ≥ 16 GB | H3 视频能跑，但必须走 NVFP4 或 GGUF，清晰度与时长二选一 |
| `t2` | 10 ~ 15 GB | ≥ 32 GB | 可上 int8 全量，不必依赖 GGUF |
| `t3` | 16 ~ 23 GB | ≥ 64 GB | 「万物皆可接续」全链路 + 放大 |
| `t4` | 24 GB+ | ≥ 96 GB | 长视频 + 多 LoRA + 4K 放大 |

**为什么内存是硬门槛**：参考机（8 GB 显存 + 16 GB 内存）实测跑 1.0MP × 5 秒时，
显存峰值 7.3 GB 打得满，而**可用内存最低只剩 0.19 GB** —— 真正的瓶颈是内存。
内存不够的机器，显存再大也会在加载权重阶段被换页拖死。

实测数据（参考机：一台 8 GB 显存的 NVIDIA 笔记本 + 16 GB 内存）：

| 配置 | 1.0MP × 5 秒 | 显存峰值 |
|---|---|---|
| int8 全套 | 415 秒 | 7.43 GB |
| **NVFP4 扩散 + NVFP4 文本编码器** | **245 秒** | ≈ 7.3 GB |

详细档位定义与依据写在 [`catalog/hardware-tiers.json`](catalog/hardware-tiers.json)，
每个数字都带 `basis` 字段标明是「实测」还是「估算」。

---

## 仓库里有什么

| 目录 | 内容 |
|---|---|
| `server/` | 零依赖 HTTP 服务 + 方案引擎 + 探测 + 提示词生成 |
| `web/` | 五步向导前端（原生 HTML/CSS/JS，无构建步骤） |
| `catalog/` | 硬件档位、权重注记、插件注记、工作流注记（`.meta.json` 是人工写的，其余是生成的） |
| `workflows/` | 工作流 JSON 本体 + `api/`（无头调用）+ `optional-r18/`（成人内容，默认不装） |
| `tools/` | 扫描、生成、校验、冒烟测试、CLI |
| `docs/` | 自动生成的对照表 + 常见问题 |

- 权重与插件对照表：[`docs/模型与显存对照表.md`](docs/模型与显存对照表.md) · [`docs/插件清单.md`](docs/插件清单.md)
- 工作流总表：[`docs/工作流总表.md`](docs/工作流总表.md)
- 常见问题：[`docs/常见问题.md`](docs/常见问题.md)

### 随仓库分发的工作流

`workflows/` 下共 26 份图（5 份界面可用 + 19 份 API 图 + 2 份 18+）。向导只会挑与你档位和目标匹配的那几份。

| 工作流 | 目标 | 说明 |
|---|---|---|
| `Krea2-文生图.json` | 图片生成 | 依赖最少，**建议第一份拿它验证链路通不通** |
| `动漫通用反推流自用V2.6.json` | 图片 / 反推 | 上传图 → 反推标签 → 改标签 → 出图，三条模型通道 |
| `▶▷MiniMaxH3-加速视频流整合-增强版.json` | 视频生成 | 主力图，NVFP4 权重，实测 245 秒/条 |
| `▶▷MiniMaxH3-加速视频流整合.json` | 视频生成 | 同一件事的 GGUF 路线，**与增强版二选一** |
| `最终版 万物皆可接续工作流 国庆快乐v1.1.json` | 视频 / 动作迁移 | 进阶全家桶，需要 t3 档以上 |

> ⚠️ **18+ 内容**：`workflows/optional-r18/` 下 2 份动作迁移图引用了成人内容 LoRA。
> 它们**只在用户显式勾选时**才会进入清单，安装脚本默认也不会复制。
> 详见 [`workflows/optional-r18/README.md`](workflows/optional-r18/README.md)。

---

## 命令参考

```bash
node server/server.mjs [--port 8030] [--no-open]   # 起服务
node tools/cli.mjs probe                           # 探测硬件
node tools/cli.mjs plan   --vram 8 --ram 16 --goals video,image [--r18] [--disk 100]
node tools/cli.mjs prompt --vram 8 --ram 16 --goals video [--out file.md]
node tools/cli.mjs install --comfy "<ComfyUI 根目录>" [--r18] [--overwrite] [--dry]
node tools/cli.mjs check                           # 目录自检
node tools/build-catalog.mjs [--check]             # 重建/校验目录
node tools/render-docs.mjs                         # 重新生成 docs 里的对照表
node tools/smoke-test.mjs                          # 冒烟测试（58 项断言）
```

`npm run check` 会连着跑：目录双向校验 → 目录自检 → 前端一致性 → 冒烟测试。

---

## 数据可信度：哪些是实测，哪些是估算

这个仓库里刻意区分了三种信息，不允许混着写：

1. **扫描得到的**（权重文件名、目录名、节点类型）—— 来自工作流 JSON，是唯一的权威来源。
2. **核对过的来源**（标记为「地址可靠」的插件与 `HF:` 前缀的仓库）—— 能在工作流 JSON 里找到直链证据，
   或来自原部署脚本的实测记录。
3. **估算**（标 `*` 的体积、`t2`~`t4` 档的耗时）—— 显式写了 `basis` 说明怎么推的，不假装是实测。

**没核对过的插件地址一律不写死**，只给节点名与搜索线索，让用户的 agent 去确认。
这是刻意的取舍：写一个错的仓库地址比不写更糟。

---

## 许可与第三方内容

工作台本体是 [MIT](LICENSE)。

随仓库分发的**工作流 JSON 来自第三方整合包与作者自用版本**，仅作「按图索骥的下模型清单」用途分发，
**本身不含任何模型权重**。其中的第三方 LoRA / 模型文件名、以及工作流里出现的外部链接
（HuggingFace、夸克网盘、B 站等）版权与内容责任均归原作者。使用前请自行确认来源合法。

模型权重一律不进 git（见 `.gitignore`）。

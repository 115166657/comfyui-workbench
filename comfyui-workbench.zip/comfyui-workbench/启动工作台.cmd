@echo off
REM ASCII-only on purpose: cmd.exe parses .cmd files in the ANSI codepage,
REM so Chinese text here would show up as mojibake. Chinese docs live in README.md.
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   [!] Node.js not found in PATH.
  echo       Install Node.js 18 or newer from https://nodejs.org/ then run this again.
  echo.
  pause
  exit /b 1
)

echo.
echo   Starting ComfyUI Workbench...
echo   A browser tab will open. Press Ctrl+C in this window to stop.
echo.
node server\server.mjs %*
if errorlevel 1 pause
endlocal

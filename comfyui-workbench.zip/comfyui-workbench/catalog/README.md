# catalog/ —— 数据层

这个目录分两类文件，**别搞混**：

## 人工写的（改了要复核）

| 文件 | 内容 |
|---|---|
| `hardware-tiers.json` | 硬件档位定义、视频参数上限、分档规则。每个数值带 `basis` 标明实测还是估算 |
| `models.meta.json` | 每个权重的人工注记：体积、用途、来源、目标子目录、档位、同槽位变体 |
| `plugins.meta.json` | 插件清单 + `coreNodeTypes`（ComfyUI 自带的节点，不算插件） |
| `workflows.meta.json` | 每份工作流的标题、用途、分级、目标、最低档位 |

## 生成的（别手改）

由 `node tools/build-catalog.mjs` 从上面四份 + `workflows/` 扫描结果生成：

| 文件 | 内容 |
|---|---|
| `scan.json` | 工作流扫描原始结果（每份图引用了哪些权重、用了哪些节点类型） |
| `models.json` | 权重目录（扫描 + 注记合并后的结果，服务端实际读这个） |
| `workflows.json` | 工作流目录（补上了扫描出来的权重与节点依赖） |
| `plugins.json` | 插件目录（补上了「哪份图用到它」） |
| `uncovered-nodes.json` | 用到但没匹配到任何插件的节点类型 |

## 校验规则

`node tools/build-catalog.mjs --check` 会在下列任何一条不成立时**非零退出**：

1. **权重双向对齐** —— 扫到的必须有注记，注记的必须扫得到。
2. **工作流双向对齐** —— `workflows/` 下的文件与 `workflows.meta.json` 里的条目必须一一对应。
3. **目录逐字一致** —— 注记里的目标子目录必须与工作流 JSON 里引用的路径一模一样。
   （工作流里写 `Minimax_H3/nvfp4/x.safetensors`，那模型就必须落在 `models/Minimax_H3/nvfp4/`。
   差一个字符，模型下好了也不会出现在下拉框里。）
4. **插件 `provides` 不重复** —— 同一个节点类型被两个插件声明会给出警告。

这套规则的意义：让「清单」和「工作流」不可能悄悄漂移。
你往 `workflows/` 里丢一份新图，忘了注记，`npm run check` 会告诉你缺哪几个文件。

# workflows/ —— 随仓库分发的工作流

这些 JSON 是**界面版**（ComfyUI 里 `Load` 打开就能用），跟 `api/` 里的 API 格式图不同。

## 怎么导入

工作台第 5 步可以一键复制进 `<ComfyUI>/user/default/workflows/`，也可以手动拷。

```bash
node tools/cli.mjs install --comfy "D:\ComfyUI\ComfyUI" --dry   # 先看会复制什么
node tools/cli.mjs install --comfy "D:\ComfyUI\ComfyUI"         # 真复制
```

默认**不覆盖**同名文件 —— 你那份可能已经被自己改过了。确实要覆盖加 `--overwrite`。

## 文件清单

| 文件 | 目标 | 最低档位 | 说明 |
|---|---|---|---|
| `Krea2-文生图.json` | 图片生成 | t1 | 依赖最少，用来验证链路 |
| `动漫通用反推流自用V2.6.json` | 图片 / 反推 | t1 | 三条模型通道，缺插件会一屏红框 |
| `▶▷MiniMaxH3-加速视频流整合-增强版.json` | 视频生成 | t1 | 主力图（NVFP4） |
| `▶▷MiniMaxH3-加速视频流整合.json` | 视频生成 | t1 | GGUF 路线，与增强版二选一 |
| `最终版 万物皆可接续工作流 国庆快乐v1.1.json` | 视频 / 动作迁移 | t3 | 进阶全家桶 |

每个文件引用了哪些权重、要放到哪个子目录，看
[`../docs/模型与显存对照表.md`](../docs/模型与显存对照表.md)，
或者直接跑 `node tools/cli.mjs plan --vram 8 --ram 16 --goals video`。

## 改之前先知道

- **不要手改文件名。** 工作台生成的清单直接引用这些文件名，改名会让清单对不上。
  真要改，改完跑 `node tools/build-catalog.mjs --check`。
- **不要改图里节点的参数值。** 分辨率、步数、文件名都是按 8G 显存档调过的。
- H3 那两份大图里有大量节点是**被旁路器关着**的（`mode=4`）—— 打开图后用界面上的
  `Fast Groups Bypasser (rgthree)` 选择要跑的分支，别以为所有节点都会执行。
- 图里的模型路径是**相对 `models/` 的子路径**，带子目录（例如 `Minimax_H3/nvfp4/xxx.safetensors`）。
  子目录名必须一模一样，否则下拉框里选不到。

## 来源说明

这几份图来自第三方整合包与作者自用版本，随仓库分发的原因是：**工作台要靠它们反查该下哪些权重**。
它们本身不含任何模型权重。其中出现的第三方链接（HuggingFace / 夸克网盘 / B 站等）版权归原作者。

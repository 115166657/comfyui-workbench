/**
 * 工作台服务端。零依赖，只用 Node 内置模块。
 *
 * 它做的事只有三件：探测这台机器的硬件、按硬件算出该装什么、把结果写成一段提示词。
 * 它【不下载模型、不装插件、不改用户的 ComfyUI】—— 唯一会写盘的操作是把工作流复制进
 * ComfyUI 的 user/default/workflows，而且默认不覆盖同名文件。
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { probeAll } from './lib/probe.mjs';
import { buildPlan, loadCatalog, GOALS } from './lib/plan.mjs';
import { buildAgentPrompt } from './lib/agent-prompt.mjs';
import { installWorkflows, listInstallable } from './lib/install.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const webDir = path.join(root, 'web');
const dataDir = path.join(root, 'data');
const profileFile = path.join(dataDir, 'profile.json');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
  '.png': 'image/png',
  '.md': 'text/markdown; charset=utf-8',
};

const readBody = (req) =>
  new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (c) => {
      raw += c;
      if (raw.length > 2 * 1024 * 1024) reject(new Error('请求体过大'));
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch (e) {
        reject(new Error('请求体不是合法 JSON：' + e.message));
      }
    });
    req.on('error', reject);
  });

const sendJson = (res, code, obj) => {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(body);
};

/** 用户填的配置存一份，下次打开不用重填。存的是用户自己填的东西，不是探测结果。 */
function readProfile() {
  try {
    return JSON.parse(fs.readFileSync(profileFile, 'utf8'));
  } catch {
    return null;
  }
}
function writeProfile(p) {
  fs.mkdirSync(dataDir, { recursive: true });
  fs.writeFileSync(profileFile, JSON.stringify(p, null, 2) + '\n', 'utf8');
}

/** 把前端来的 profile 归一化：数字字段一律过一遍 Number，避免 "8" 这种字符串漏进来。 */
function normalizeProfile(raw = {}) {
  // ⚠️ 必须先挡掉 null / '' —— Number(null) 是 0 而且是有限数，
  // 直接放过去会让「没填磁盘空间」变成「磁盘 0GB」，进而报一个假的磁盘不足警告。
  const num = (v, d = null) => {
    if (v === null || v === undefined || v === '') return d;
    const n = Number(v);
    return Number.isFinite(n) ? n : d;
  };
  return {
    gpuName: raw.gpuName || null,
    hasNvidia: raw.hasNvidia !== false,
    vramGB: num(raw.vramGB, 8),
    ramGB: num(raw.ramGB, 16),
    diskFreeGB: num(raw.diskFreeGB, null),
    goals: Array.isArray(raw.goals) && raw.goals.length ? raw.goals : ['image'],
    includeR18: !!raw.includeR18,
    comfyPath: raw.comfyPath || null,
    comfyModelsDir: raw.comfyModelsDir || (raw.comfyPath ? path.join(raw.comfyPath, 'models') : null),
    os: raw.os || null,
    arch: raw.arch || null,
    cpu: raw.cpu || null,
    network: raw.network || null,
  };
}

function serveStatic(req, res, urlPath) {
  const rel = urlPath === '/' ? 'index.html' : urlPath.replace(/^\/+/, '');
  const file = path.join(webDir, rel);
  // 目录穿越防护：解析后的绝对路径必须在 webDir 内
  if (!path.resolve(file).startsWith(path.resolve(webDir))) {
    res.writeHead(403).end('forbidden');
    return;
  }
  fs.readFile(file, (err, buf) => {
    if (err) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }).end('not found: ' + rel);
      return;
    }
    res.writeHead(200, { 'content-type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' });
    res.end(buf);
  });
}

export function createServer() {
  return http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1');
    const p = url.pathname;

    try {
      if (p === '/api/bootstrap') {
        const cat = loadCatalog();
        const env = await probeAll();
        // 探测到的值只作为「初值」，是否采用由用户在第二步决定
        const saved = readProfile();
        return sendJson(res, 200, {
          ok: true,
          goals: GOALS,
          tiers: cat.tiers.tiers,
          measuredOn: cat.tiers.measuredOn,
          nonNvidia: cat.tiers.nonNvidia,
          counts: {
            workflows: cat.workflows.length,
            uiWorkflows: cat.workflows.filter((w) => w.category !== 'api').length,
            models: cat.models.length,
            plugins: cat.plugins.length,
          },
          workflows: cat.workflows,
          env,
          savedProfile: saved,
          repoRoot: root,
        });
      }

      if (p === '/api/plan' && req.method === 'POST') {
        const profile = normalizeProfile(await readBody(req));
        const plan = buildPlan(profile);
        return sendJson(res, 200, { ok: true, profile, plan });
      }

      if (p === '/api/agent-prompt' && req.method === 'POST') {
        const body = await readBody(req);
        const profile = normalizeProfile(body.profile || body);
        const plan = buildPlan(profile);
        const markdown = buildAgentPrompt(profile, plan);
        return sendJson(res, 200, { ok: true, markdown, plan });
      }

      if (p === '/api/profile' && req.method === 'POST') {
        const profile = normalizeProfile(await readBody(req));
        writeProfile(profile);
        return sendJson(res, 200, { ok: true, profile });
      }

      if (p === '/api/install-workflows' && req.method === 'POST') {
        const body = await readBody(req);
        const comfyPath = body.comfyPath || normalizeProfile(body.profile || {}).comfyPath;
        const files = Array.isArray(body.files) && body.files.length
          ? body.files
          : listInstallable({ includeR18: !!body.includeR18, includeApi: false });
        const result = installWorkflows({ comfyPath, files, overwrite: !!body.overwrite, dryRun: !!body.dryRun });
        return sendJson(res, result.ok ? 200 : 400, result);
      }

      if (p === '/api/health') {
        return sendJson(res, 200, { ok: true, node: process.version, pid: process.pid });
      }

      if (p.startsWith('/api/')) return sendJson(res, 404, { ok: false, error: 'unknown api: ' + p });
      return serveStatic(req, res, p);
    } catch (e) {
      return sendJson(res, 500, { ok: false, error: e.message });
    }
  });
}

/** 起服务。端口被占就往后顺延，最多试 20 个 —— 比直接报 EADDRINUSE 友好。 */
export function start(port = 8030, host = '127.0.0.1') {
  const server = createServer();
  return new Promise((resolve, reject) => {
    let tries = 0;
    const attempt = (pt) => {
      server.once('error', (err) => {
        if (err.code === 'EADDRINUSE' && tries < 20) {
          tries += 1;
          attempt(pt + 1);
        } else reject(err);
      });
      server.listen(pt, host, () => resolve({ server, port: pt, url: `http://${host}:${pt}` }));
    };
    attempt(port);
  });
}

if (process.argv[1] && process.argv[1].endsWith('server.mjs')) {
  const portArg = process.argv.indexOf('--port');
  const port = portArg >= 0 ? Number(process.argv[portArg + 1]) : 8030;
  const noOpen = process.argv.includes('--no-open');
  start(port)
    .then(({ url }) => {
      console.log(`\n  ComfyUI 工作台已启动：${url}\n`);
      console.log('  按 Ctrl+C 停止。数据都在本地，不会上传任何东西。\n');
      if (!noOpen) {
        const cmd = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]] : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
        import('node:child_process').then(({ spawn }) => {
          try {
            spawn(cmd[0], cmd[1], { detached: true, stdio: 'ignore' }).unref();
          } catch {
            /* 打不开浏览器不影响服务 */
          }
        });
      }
    })
    .catch((e) => {
      console.error('启动失败：', e.message);
      process.exit(1);
    });
}

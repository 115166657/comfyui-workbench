#!/usr/bin/env sh
# macOS / Linux 启动脚本。Windows 用「启动工作台.cmd」。
set -e
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "[!] 没有找到 Node.js。请先安装 Node.js 18 或更高版本：https://nodejs.org/"
  exit 1
fi

echo
echo "  正在启动 ComfyUI 工作台…"
echo "  浏览器会自动打开；在这个终端里按 Ctrl+C 停止。"
echo
exec node server/server.mjs "$@"

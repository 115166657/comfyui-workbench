#!/usr/bin/env node
/**
 * 冒烟测试：起一个临时服务，把向导会走的每条接口都打一遍，并断言结果。
 *
 * 为什么值得存在：这套推荐逻辑的输入空间很大（4 个档位 × 4 个目标 × 有无 18+），
 * 网页上点一遍只能覆盖一条路径。这里把关键组合固化成断言，改逻辑时一眼能看出有没有跑偏。
 *
 * 用法：node tools/smoke-test.mjs
 */
import { start } from '../server/server.mjs';

let pass = 0;
const fails = [];
const ok = (cond, msg) => (cond ? pass++ : fails.push(msg));

const POST = async (base, path, body) => {
  const r = await fetch(base + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return { status: r.status, json: await r.json() };
};

const { server, port, url } = await start(8031, '127.0.0.1');
console.log(`临时服务已起：${url}\n`);

try {
  // ---- 1) 引导接口 ----
  const boot = await (await fetch(url + '/api/bootstrap')).json();
  ok(boot.ok === true, 'bootstrap 未返回 ok');
  ok(boot.env && boot.env.os, 'bootstrap 缺少环境探测结果');
  ok(boot.counts.uiWorkflows >= 5, `可用工作流过少：${boot.counts?.uiWorkflows}`);
  ok(boot.goals.length === 4, `目标数应为 4，实际 ${boot.goals.length}`);
  ok(boot.tiers.length === 5, `档位数应为 5，实际 ${boot.tiers.length}`);

  // ---- 2) 静态页 ----
  const page = await fetch(url + '/');
  const html = await page.text();
  ok(page.status === 200 && html.includes('ComfyUI 工作台'), '首页没取到或标题不对');
  ok((await fetch(url + '/app.js')).status === 200, 'app.js 取不到');
  ok((await fetch(url + '/style.css')).status === 200, 'style.css 取不到');

  // ---- 3) 目录穿越防护 ----
  const evil = await fetch(url + '/../package.json');
  ok(evil.status === 403 || evil.status === 404, `目录穿越没被挡住：${evil.status}`);

  // ---- 4) 档位判定 ----
  const cases = [
    { p: { vramGB: 8, ramGB: 16, diskFreeGB: 60, goals: ['video'] }, tier: 't1', label: '8G/16G 视频' },
    { p: { vramGB: 12, ramGB: 64, diskFreeGB: 200, goals: ['video'] }, tier: 't2', label: '12G/64G 视频' },
    { p: { vramGB: 24, ramGB: 64, diskFreeGB: 400, goals: ['video'] }, tier: 't3', label: '24G/64G 视频' },
    { p: { vramGB: 48, ramGB: 128, diskFreeGB: 900, goals: ['video'] }, tier: 't4', label: '48G/128G 视频' },
    { p: { vramGB: 4, ramGB: 8, diskFreeGB: 40, goals: ['video'] }, tier: 't0', label: '4G/8G 视频' },
    { p: { vramGB: 32, ramGB: 16, diskFreeGB: 400, goals: ['video'] }, tier: 't1', label: '32G 显存但只有 16G 内存（应被内存门槛压低）' },
    { p: { vramGB: 8, ramGB: 16, diskFreeGB: 60, goals: ['video'], hasNvidia: false }, tier: 't0', label: '无 N 卡' },
  ];
  for (const c of cases) {
    const { json } = await POST(url, '/api/plan', c.p);
    ok(json.ok, `${c.label}: /api/plan 失败 ${json.error || ''}`);
    ok(json.plan?.tier?.id === c.tier, `${c.label}: 期望档位 ${c.tier}，实际 ${json.plan?.tier?.id}`);
  }

  // ---- 5) 同槽位去重：8G 视频档不该被要求下 int8 + NVFP4 + GGUF 三套主干 ----
  const v8 = (await POST(url, '/api/plan', { vramGB: 8, ramGB: 16, goals: ['video'] })).json.plan;
  const unets = v8.models.required.filter((m) => m.variantOf === 'h3-fl2va').map((m) => m.variant);
  ok(unets.length === 1, `h3-fl2va 槽位应只留 1 套，实际留了 ${unets.length} 套：${unets.join('/')}`);
  ok(unets[0] === 'nvfp4', `8G 档应选 nvfp4，实际选了 ${unets[0]}`);
  ok(v8.models.alternatives.length >= 2, '应列出被排除的同槽位备选');
  ok(v8.totals.requiredGB < 60, `8G 视频档必装体积应小于 60GB（去重前是 142GB），实际 ${v8.totals.requiredGB}GB`);

  // ---- 6) 跨工作流的同名槽位不能被误删：视频图用 4B、反推图用 9B，两个都要 ----
  const both = (await POST(url, '/api/plan', { vramGB: 8, ramGB: 16, goals: ['video', 'reverse'] })).json.plan;
  const llm = both.models.required.filter((m) => m.variantOf === 'reverse-llm').map((m) => m.variant);
  ok(llm.includes('4b') && llm.includes('9b'), `4B 与 9B 都应保留，实际：${[...new Set(llm)].join('/')}`);

  // ---- 7) 18+ 开关 ----
  const noR18 = (await POST(url, '/api/plan', { vramGB: 24, ramGB: 64, goals: ['motion'] })).json.plan;
  ok(noR18.models.r18.length === 0, '没勾选时不该出现 18+ 权重');
  ok(!noR18.workflows.required.concat(noR18.workflows.optional).some((w) => w.adult), '没勾选时不该出现 18+ 工作流');
  const withR18 = (await POST(url, '/api/plan', { vramGB: 24, ramGB: 64, goals: ['motion'], includeR18: true })).json.plan;
  ok(withR18.models.r18.length > 0, '勾选后应列出 18+ 权重');

  // ---- 8) 每份必装工作流引用的每个权重都要有去处和来源 ----
  for (const w of v8.workflows.required) {
    for (const name of w.models) {
      const m = v8.models.required.find((x) => x.name === name) || v8.models.recommended.find((x) => x.name === name) || v8.models.alternatives.find((a) => a.files.includes(name));
      ok(!!m, `${w.file} 引用的 ${name} 既不在必装也不在推荐也不在备选里 —— 用户会漏下这个文件`);
    }
  }

  // ---- 9) Agent 提示词 ----
  const pr = await POST(url, '/api/agent-prompt', { vramGB: 8, ramGB: 16, goals: ['video'] });
  const md = pr.json.markdown;
  ok(pr.json.ok && md.length > 3000, `提示词过短：${md?.length}`);
  for (const needle of ['装插件', '下权重', '导入工作流', '验证', '禁止事项', 'Comfy-Org/MiniMax-H3', 'models/Minimax_H3/nvfp4', 'NVFP4']) {
    ok(md.includes(needle), `提示词缺少关键段落/信息：${needle}`);
  }
  ok(md.includes('不要下载'), '提示词没有明确告知同槽位备选不要下载');

  // t0 的提示词必须劝退而不是照单下载
  const t0md = (await POST(url, '/api/agent-prompt', { vramGB: 4, ramGB: 8, goals: ['video'] })).json.markdown;
  ok(t0md.includes('跑不了本仓库的主链路'), 't0 档提示词没有给出劝退与降级方案');

  // ---- 10) 工作流导入：dry-run 不写盘，写错路径要被挡住 ----
  const bad = await POST(url, '/api/install-workflows', { comfyPath: 'C:\\Windows', dryRun: true });
  ok(bad.status === 400 && /main\.py/.test(bad.json.error || ''), `无效路径应有明确拒绝，实际 ${bad.status} ${bad.json.error || ''}`);

  const dry = await POST(url, '/api/install-workflows', { comfyPath: null, dryRun: true });
  ok(dry.status === 400, '缺少 comfyPath 时应拒绝');

  // ---- 11) profile 持久化 ----
  const sp = await POST(url, '/api/profile', { vramGB: 8, ramGB: 16, goals: ['video'], comfyPath: 'D:\\ComfyUI\\ComfyUI' });
  ok(sp.json.ok && sp.json.profile.vramGB === 8, 'profile 保存失败');
  // 回归：Number(null) === 0，不挡住的话「没填磁盘」会被存成「磁盘 0GB」，
  // 下次打开就报一个假的「磁盘不足」警告。
  ok(sp.json.profile.diskFreeGB === null, `没传磁盘时应存成 null，实际存成 ${JSON.stringify(sp.json.profile.diskFreeGB)}`);
  const boot2 = await (await fetch(url + '/api/bootstrap')).json();
  ok(boot2.savedProfile?.vramGB === 8, 'profile 没有被读回来');
  ok(boot2.savedProfile?.diskFreeGB === null, `读回来的磁盘字段应仍是 null，实际 ${JSON.stringify(boot2.savedProfile?.diskFreeGB)}`);

  const withDisk = await POST(url, '/api/plan', { vramGB: 8, ramGB: 16, goals: ['video'], diskFreeGB: null });
  ok(
    !withDisk.json.plan.warnings.some((w) => w.includes('剩余磁盘')),
    '磁盘字段为 null 时不该产生任何磁盘相关警告'
  );
  const zeroDisk = await POST(url, '/api/plan', { vramGB: 8, ramGB: 16, goals: ['video'], diskFreeGB: 0 });
  ok(
    zeroDisk.json.plan.warnings.some((w) => w.includes('剩余磁盘')),
    '用户真的填了 0 时应当警告磁盘不足'
  );

  // ---- 12) 未知接口 ----
  ok((await fetch(url + '/api/nope')).status === 404, '未知接口应返回 404');
} catch (e) {
  fails.push('测试过程抛错：' + e.message);
} finally {
  server.close();
}

console.log(`通过 ${pass} 项`);
if (fails.length) {
  console.error(`\n✗ 失败 ${fails.length} 项：`);
  for (const f of fails) console.error('  - ' + f);
  process.exit(1);
}
console.log('✓ 冒烟测试全绿');

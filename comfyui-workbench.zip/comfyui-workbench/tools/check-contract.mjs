#!/usr/bin/env node
/**
 * 前后端契约检查：app.js 里读取的每个字段路径（plan.xxx / env.xxx / boot.xxx / w.xxx），
 * 必须在真实响应对象里真的存在。
 *
 * 为什么需要：这个前端没有 TypeScript 兜底。后端改一个字段名，前端不会报错，
 * 只会在页面上显示 undefined —— 而且是那种"要点击到第五步才看见"的 undefined。
 * 静态检查比人眼可靠。
 *
 * 用法：node tools/check-contract.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildPlan, GOALS } from '../server/lib/plan.mjs';
import { buildAgentPrompt } from '../server/lib/agent-prompt.mjs';
import { probeAll } from '../server/lib/probe.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const js = fs.readFileSync(path.join(root, 'web', 'app.js'), 'utf8');

/** 取一个对象的字段路径，支持数组（自动取第 0 个元素）。 */
function resolve(root, dotted) {
  let cur = root;
  for (const part of dotted.split('.')) {
    if (cur == null) return { ok: false, at: part };
    if (Array.isArray(cur)) {
      if (!cur.length) return { ok: true, empty: true }; // 空数组无法校验，放过
      cur = cur[0];
    }
    if (typeof cur !== 'object' || !(part in cur)) return { ok: false, at: part };
    cur = cur[part];
  }
  return { ok: true };
}

const PROFILE = { vramGB: 8, ramGB: 16, diskFreeGB: 60, hasNvidia: true, goals: ['image', 'reverse', 'video'], includeR18: true, comfyPath: 'D:\\ComfyUI\\ComfyUI' };
// 无 N 卡时 plan.nonNvidia 才有值；两套都拿来当样本，否则那条分支永远检查不到
const NO_NVIDIA = { ...PROFILE, hasNvidia: false, vramGB: 4, ramGB: 8 };
const plan = buildPlan(PROFILE);
const planNoNv = buildPlan(NO_NVIDIA);

const fixtures = {
  plan: planNoNv.nonNvidia ? Object.assign(Object.create(plan), plan, { nonNvidia: planNoNv.nonNvidia }) : plan,
  env: await probeAll(),
  boot: {
    ok: true,
    goals: GOALS,
    tiers: plan ? [] : [],
    counts: { workflows: 26, uiWorkflows: 7, models: 49, plugins: 21 },
    workflows: [],
    env: await probeAll(),
    savedProfile: PROFILE,
    repoRoot: root,
  },
  savedProfile: PROFILE,
};

/** 数组/字符串的内建成员，不是数据字段，遇到就截断。 */
const BUILTIN = new Set([
  'length', 'map', 'join', 'filter', 'some', 'every', 'find', 'includes', 'forEach', 'slice',
  'concat', 'toFixed', 'padStart', 'padEnd', 'split', 'replace', 'trim', 'reverse', 'sort', 'flat',
]);

/** 从 app.js 里抠出所有 `fixture.xxx.yyy` 形式的读取，去掉尾巴上的内建成员。 */
function pathsFor(prefix) {
  const re = new RegExp(`\\b${prefix}\\.([A-Za-z_$][\\w$]*(?:\\.[A-Za-z_$][\\w$]*)*)`, 'g');
  const out = new Set();
  for (const m of js.matchAll(re)) {
    const parts = m[1].split('.');
    while (parts.length && BUILTIN.has(parts[parts.length - 1])) parts.pop();
    if (parts.length) out.add(parts.join('.'));
  }
  return [...out];
}

const problems = [];
for (const [key, fixture] of Object.entries(fixtures)) {
  for (const p of pathsFor(key)) {
    const r = resolve(fixture, p);
    if (!r.ok) problems.push(`${key}.${p} —— 真实响应里没有「${r.at}」这一层`);
  }
}

// 反向：plan 里前端根本没展示的关键字段（漏展示比报错更隐蔽）
const mustShow = ['totals.requiredGB', 'totals.unknownSizeCount', 'models.required', 'models.r18', 'models.alternatives', 'plugins.required', 'workflows.required', 'tier.summary', 'warnings'];
for (const p of mustShow) {
  const field = p.split('.').pop();
  if (!js.includes(field)) problems.push(`方案里的 ${p} 没有在界面上展示`);
}

// 提示词里必须包含的关键信息（防止 prompt 生成器被改坏）
const md = buildAgentPrompt(PROFILE, plan);
for (const needle of ['环境事实', '装插件', '下权重', '导入工作流', '验证', '禁止事项', '交付格式']) {
  if (!md.includes(needle)) problems.push(`Agent 提示词缺少段落：${needle}`);
}

if (problems.length) {
  console.error(`✗ 前后端契约检查发现 ${problems.length} 个问题：`);
  for (const p of problems) console.error('  - ' + p);
  process.exit(1);
}
console.log('✓ 前后端契约一致：app.js 读取的所有字段都在真实响应里，方案关键字段全部有展示');

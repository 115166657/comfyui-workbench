/**
 * 从工作流 JSON 里抽出所有 URL，作为「模型/插件的真实来源」证据。
 *
 * 为什么值得单独做一件事：ComfyUI 的下载类节点会把完整的 HuggingFace 直链
 * 写进工作流参数里。那条链接比任何二手文档都权威 —— catalog/models.meta.json
 * 里凡是标了 verified 的来源，都应该能在这里找到对应证据。
 *
 * 用法：node tools/extract-source-urls.mjs <工作流目录>
 */
import fs from 'node:fs';
import { collectWorkflowFiles } from './scan-workflows.mjs';

const URL_RE = /https?:\/\/[^\s"'\\<>\]]{6,300}/g;

export function extractUrls(dir) {
  const urls = new Map(); // url -> Set(workflow)
  for (const f of collectWorkflowFiles(dir)) {
    const txt = fs.readFileSync(f, 'utf8');
    for (const raw of txt.match(URL_RE) || []) {
      // JSON 里的 & 有时被写成 \u0026，统一还原后再去重
      const u = raw.replace(/\\u0026/g, '&').replace(/[",]+$/, '');
      if (!urls.has(u)) urls.set(u, new Set());
      urls.get(u).add(f.replace(/\\/g, '/'));
    }
  }
  return [...urls].map(([url, s]) => ({ url, workflows: [...s] })).sort((a, b) => b.workflows.length - a.workflows.length);
}

if (process.argv[1] && process.argv[1].endsWith('extract-source-urls.mjs')) {
  const dir = process.argv[2];
  if (!dir) {
    console.error('用法: node tools/extract-source-urls.mjs <工作流目录>');
    process.exit(1);
  }
  const rows = extractUrls(dir);
  console.log(`URL ${rows.length} 条`);
  for (const r of rows) console.log(`${String(r.workflows.length).padStart(3)}  ${r.url}`);
}

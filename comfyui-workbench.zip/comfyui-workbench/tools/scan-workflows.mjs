/**
 * 扫描 ComfyUI 工作流目录，反查「这份图到底引用了哪些权重文件 / 哪些自定义节点」。
 *
 * 之所以不手写清单：工作流里的模型名是本仓库唯一的权威来源，
 * 手抄一遍必然和 JSON 漂移。catalog/models.json 的键必须全部由本工具产出。
 *
 * 用法：
 *   node tools/scan-workflows.mjs <工作流目录> [--json]
 *   node tools/scan-workflows.mjs ../comfyui-deploy/workflows
 *
 * 同时支持两种格式：
 *   - 界面格式：{ "nodes": [ { "type": "...", "widgets_values": [...] } ] }
 *   - API 格式：{ "1": { "class_type": "...", "inputs": { ... } } }
 * 实现上不区分格式，直接深度遍历：任何长得像权重文件名的字符串都会被记账，
 * 同时记录它所在的节点类型，用来反推该文件属于哪个模型槽位。
 */
import fs from 'node:fs';
import path from 'node:path';

const MODEL_EXT = /\.(safetensors|sft|ckpt|pt|pth|bin|gguf|onnx|pkl)$/i;

/** 节点类型 → 模型槽位（决定文件该放进 ComfyUI 的哪个 models 子目录）。 */
const SLOT_BY_NODE = [
  [/^(UnetLoaderGGUF|UnetLoader|UNETLoader)$/i, 'diffusion_models'],
  [/^CheckpointLoader/i, 'checkpoints'],
  [/^LoraLoader/i, 'loras'],
  [/^VAELoader$/i, 'vae'],
  [/^(CLIPLoader|CLIPLoaderGGUF|DualCLIPLoader|TripleCLIPLoader)/i, 'text_encoders'],
  [/^ControlNetLoader/i, 'controlnet'],
  [/^UpscaleModelLoader$/i, 'upscale_models'],
  [/^StyleModelLoader$/i, 'style_models'],
  [/^IPAdapterModelLoader/i, 'ipadapter'],
  [/^(LLMLoader|LlamaModelLoader|TextGenerate)/i, 'LLM'],
  [/^(Tagger|WD14)/i, 'models'],
];

function slotFor(nodeType) {
  for (const [re, slot] of SLOT_BY_NODE) if (re.test(nodeType)) return slot;
  return 'unknown';
}

/** 节点类型 → 提供它的自定义节点包（用于「你需要装哪些插件」）。 */
export const PLUGIN_BY_NODE = [
  [/^UnetLoaderGGUF/i, 'ComfyUI-GGUF'],
  [/^CLIPLoaderGGUF/i, 'ComfyUI-GGUF'],
  [/^(LayerStyle|LayerColor|LayerUtility|LayerFilter|LayerMask)/i, 'ComfyUI_LayerStyle'],
  [/^(ComfyLiterals|Int|Float|String|Bool|Primitive)/, 'ComfyLiterals'],
  [/^WD14/i, 'ComfyUI-WD14-Tagger'],
  [/^(EasyUse|easy )/i, 'ComfyUI-Easy-Use'],
  [/^SeedVR2/i, 'ComfyUI-SeedVR2_VideoUpscaler'],
  [/^(MiniMax|Hailuo)/i, 'ComfyUI-MiniMax-H3'],
];

function pluginFor(nodeType) {
  for (const [re, pkg] of PLUGIN_BY_NODE) if (re.test(nodeType)) return pkg;
  return null;
}

function walk(node, visit, nodeType = null) {
  if (typeof node === 'string') return visit(node, nodeType);
  if (Array.isArray(node)) for (const v of node) walk(v, visit, nodeType);
  else if (node && typeof node === 'object') {
    const t = node.type || node.class_type || nodeType;
    for (const v of Object.values(node)) walk(v, visit, t);
  }
}

function scanFile(file) {
  const raw = fs.readFileSync(file, 'utf8');
  let doc;
  try {
    doc = JSON.parse(raw);
  } catch (e) {
    return { file, error: `JSON 解析失败: ${e.message}` };
  }
  const models = new Map(); // filename -> Set(nodeType)
  const refs = new Map(); // filename -> Set(原始相对路径，含子目录)
  const nodeTypes = new Set();
  const bySlot = new Map(); // slot -> Set(filename)

  walk(doc, (s, nodeType) => {
    if (nodeType) nodeTypes.add(nodeType);
    if (!MODEL_EXT.test(s)) return;
    const norm = s.replace(/\\/g, '/');
    const name = norm.split('/').pop();
    if (!name || name.length > 200) return;
    if (!models.has(name)) models.set(name, new Set());
    if (nodeType) models.get(name).add(nodeType);
    if (!refs.has(name)) refs.set(name, new Set());
    refs.get(name).add(norm);
    const slot = slotFor(nodeType || '');
    if (!bySlot.has(slot)) bySlot.set(slot, new Set());
    bySlot.get(slot).add(name);
  });

  return {
    file,
    nodeTypes: [...nodeTypes].sort(),
    models: Object.fromEntries([...models].map(([k, v]) => [k, [...v].sort()])),
    refs: Object.fromEntries([...refs].map(([k, v]) => [k, [...v].sort()])),
    bySlot: Object.fromEntries([...bySlot].map(([k, v]) => [k, [...v].sort()])),
  };
}

/** 递归收集目录下所有 .json（跳过 .bak 之类）。 */
export function collectWorkflowFiles(dir) {
  const out = [];
  const skip = /(\.bak|backup-before|node_modules|\.git)/i;
  (function rec(d) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (skip.test(p)) continue;
      if (e.isDirectory()) rec(p);
      else if (e.isFile() && e.name.toLowerCase().endsWith('.json')) out.push(p);
    }
  })(dir);
  return out.sort();
}

export function scanDir(dir) {
  const results = collectWorkflowFiles(dir).map(scanFile);
  const models = new Map(); // filename -> { workflows:[], nodeTypes:Set, refs:Set }
  const nodeTypes = new Map(); // nodeType -> workflows[]
  for (const r of results) {
    if (r.error) continue;
    const rel = path.relative(dir, r.file).replace(/\\/g, '/');
    for (const [name, types] of Object.entries(r.models)) {
      if (!models.has(name)) models.set(name, { workflows: [], nodeTypes: new Set(), refs: new Set() });
      const m = models.get(name);
      m.workflows.push(rel);
      for (const t of types) m.nodeTypes.add(t);
      for (const x of r.refs[name] || []) m.refs.add(x);
    }
    for (const t of r.nodeTypes) {
      if (!nodeTypes.has(t)) nodeTypes.set(t, []);
      nodeTypes.get(t).push(rel);
    }
  }
  return {
    // 只记目录名，不记绝对路径 —— 这个文件是要进 git 的，写进本机路径等于把作者的目录结构一起公开
    dir: path.basename(path.resolve(dir)),
    workflows: results.map((r) => ({
      file: path.relative(dir, r.file).replace(/\\/g, '/'),
      error: r.error,
      modelCount: r.error ? 0 : Object.keys(r.models).length,
      nodeTypes: r.nodeTypes || [],
      bySlot: r.bySlot || {},
    })),
    models: Object.fromEntries(
      [...models].map(([k, v]) => [
        k,
        {
          workflows: v.workflows,
          nodeTypes: [...v.nodeTypes].sort(),
          refs: [...v.refs].sort(),
          slot: slotFor([...v.nodeTypes][0] || ''),
        },
      ])
    ),
    nodeTypes: Object.fromEntries([...nodeTypes].map(([k, v]) => [k, v])),
  };
}

if (process.argv[1] && process.argv[1].endsWith('scan-workflows.mjs')) {
  const dir = process.argv[2];
  if (!dir) {
    console.error('用法: node tools/scan-workflows.mjs <工作流目录>');
    process.exit(1);
  }
  const r = scanDir(dir);
  const models = Object.entries(r.models).map(([name, v]) => ({ name, slot: v.slot, nodeTypes: v.nodeTypes, workflows: v.workflows }));
  if (process.argv.includes('--summary')) {
    console.log(`工作流 ${r.workflows.length} 份，引用权重 ${models.length} 个`);
    for (const m of models.sort((a, b) => a.slot.localeCompare(b.slot))) {
      console.log(`${m.slot.padEnd(16)} | ${m.name.padEnd(60)} | ${m.workflows.join(', ')}`);
    }
    process.exit(0);
  }
  console.log(JSON.stringify({ dir: r.dir, workflowCount: r.workflows.length, modelCount: models.length, models, nodeTypes: r.nodeTypes }, null, 2));
}

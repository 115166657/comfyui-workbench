/**
 * 把「工作流里真实出现的引用」和「人工注记」拼成工作台要用的目录。
 *
 * 输入：workflows/（权威：引用关系）+ catalog/*.meta.json（权威：体积/用途/来源）
 * 输出：catalog/models.json、plugins.json、workflows.json、scan.json、uncovered-nodes.json
 *
 * 为什么不让 models.json 手写：手写的清单一定会和工作流漂移，
 * 而漂移的后果是用户照着下完模型，图里还是一屏红框。
 * 所以这里做【双向校验】：扫到的必须有注记，注记的必须扫得到，少一个就非零退出。
 *
 * 用法：
 *   node tools/build-catalog.mjs            # 生成
 *   node tools/build-catalog.mjs --check    # 只校验不写文件（CI 用）
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { scanDir } from './scan-workflows.mjs';
import { extractUrls } from './extract-source-urls.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const catDir = path.join(root, 'catalog');
const wfDir = path.join(root, 'workflows');

const readJson = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
const writeJson = (p, v) => fs.writeFileSync(p, JSON.stringify(v, null, 2) + '\n', 'utf8');

const checkOnly = process.argv.includes('--check');
const errors = [];
const warnings = [];

const meta = {
  models: readJson(path.join(catDir, 'models.meta.json')),
  plugins: readJson(path.join(catDir, 'plugins.meta.json')),
  workflows: readJson(path.join(catDir, 'workflows.meta.json')),
  tiers: readJson(path.join(catDir, 'hardware-tiers.json')),
};

const scan = scanDir(wfDir);
const urls = extractUrls(wfDir);

// ---------- 1) 工作流清单：meta 与磁盘双向对齐 ----------
const onDisk = new Set(scan.workflows.map((w) => w.file));
const described = new Map(); // file -> meta entry（附 category）
for (const w of meta.workflows.ui || []) described.set(w.file, { ...w, category: 'ui' });
for (const w of meta.workflows.optionalR18 || []) {
  described.set(`optional-r18/${w.file}`, { ...w, category: 'optional-r18', file: `optional-r18/${w.file}` });
}
for (const [file, w] of Object.entries(meta.workflows.api?.files || {})) {
  described.set(`api/${file}`, { ...w, category: 'api', file: `api/${file}` });
}

for (const f of onDisk) if (!described.has(f)) errors.push(`工作流未注记：${f}`);
for (const f of described.keys()) if (!onDisk.has(f)) errors.push(`注记了不存在的工作流：${f}`);

// ---------- 2) 权重清单：meta 与扫描结果双向对齐 ----------
const scannedModels = Object.entries(scan.models);
const metaFiles = meta.models.files || {};
for (const [name, info] of scannedModels) {
  if (!metaFiles[name]) errors.push(`权重未注记：${name}（出现在 ${info.workflows.length} 份工作流里）`);
}
for (const name of Object.keys(metaFiles)) {
  if (!scan.models[name]) errors.push(`注记了没被任何工作流引用的权重：${name}`);
}

// 目录名必须与工作流里的引用逐字一致 —— 这是「模型下好了但下拉框里选不到」的唯一根因。
// 工作流里带子目录的引用（Minimax_H3/nvfp4/x.safetensors）就是 ComfyUI 实际查找的路径。
for (const [name, info] of scannedModels) {
  const m = metaFiles[name];
  if (!m || !m.dir) continue;
  const refDirs = new Set(info.refs.map((r) => (r.includes('/') ? r.slice(0, r.lastIndexOf('/')) : '')));
  if (refDirs.size === 1 && !refDirs.has(m.dir) && !refDirs.has('')) {
    errors.push(`目录对不上：${name}\n      工作流里引用的是 "${[...refDirs][0]}/${name}"\n      注记写的是 "${m.dir}"`);
  }
}

// ---------- 3) 插件：provides 不能重复，且要能解释观察到的节点 ----------
const providedBy = new Map(); // nodeType -> pluginId
for (const p of meta.plugins.plugins) {
  for (const n of p.provides || []) {
    if (providedBy.has(n)) warnings.push(`节点 ${n} 被 ${providedBy.get(n)} 与 ${p.id} 同时声明，按先出现的算`);
    else providedBy.set(n, p.id);
  }
}
const core = new Set(meta.plugins.coreNodeTypes || []);
// 扫描器会把连线类型名（IMAGE / MODEL / LATENT…）也记进来，这些不是节点，单独滤掉
const NON_NODE = new Set([
  '*', 'IMAGE', 'MODEL', 'CLIP', 'VAE', 'LATENT', 'CONDITIONING', 'MASK', 'AUDIO', 'VIDEO',
  'GUIDER', 'NOISE', 'SAMPLER', 'SIGMAS', 'BOOLEAN', 'FLOAT', 'INT', 'STRING', 'COMBO', 'NUMBER',
  'DICT', 'BOX', 'LORA_STACK', 'IMAGEUPLOAD', 'input', 'output', 'temp',
  'FLOAT,INT,BOOLEAN', 'INT,FLOAT,IMAGE,LATENT', 'COMFY_DYNAMICCOMBO_V3',
]);
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const uncovered = Object.keys(scan.nodeTypes)
  .filter((n) => !core.has(n) && !providedBy.has(n) && !NON_NODE.has(n) && !UUID_RE.test(n))
  .sort();

// ---------- 4) 组装 models.json ----------
const models = scannedModels
  .map(([name, info]) => {
    const m = metaFiles[name] || {};
    const urlsForFile = urls.filter((u) => u.url.includes(encodeURIComponent(name)) || u.url.includes(name));
    return {
      name,
      slot: m.slot || info.slot,
      role: m.role || null,
      sizeGB: m.sizeGB ?? null,
      sizeGBEst: m.sizeGBEst ?? null,
      sizeBasis: m.sizeBasis || null,
      sizeNote: m.sizeNote || null,
      minTier: m.minTier ?? null,
      dir: m.dir ?? '',
      dirNote: m.dirNote || null,
      source: m.source || { kind: 'search', hint: '未注记来源' },
      pluginDep: m.pluginDep || null,
      optional: !!m.optional,
      r18: !!m.r18,
      // 同槽位互斥变体：同一个位置（比如 H3 的 FL2VA 主干）往往有 int8 / NVFP4 / GGUF 几套
      // 互斥的权重。不加这个概念，方案就会让用户把三套全下一遍。
      variantOf: m.variantOf || null,
      variant: m.variant || null,
      preferredFor: m.preferredFor || [],
      note: m.note || null,
      refs: info.refs,
      nodeTypes: info.nodeTypes,
      usedBy: info.workflows,
      directUrls: urlsForFile.map((u) => u.url),
    };
  })
  .sort((a, b) => (a.slot + a.name).localeCompare(b.slot + b.name));

// ---------- 5) 组装 workflows.json（补上扫描出来的依赖） ----------
const wfIndex = new Map(scan.workflows.map((w) => [w.file, w]));
const workflows = [...described.values()]
  .map((w) => {
    const s = wfIndex.get(w.file);
    const wfModels = models.filter((m) => m.usedBy.includes(w.file));
    return {
      file: w.file,
      category: w.category,
      title: w.title || w.file,
      purpose: w.purpose || null,
      level: w.level || 'optional',
      minTier: w.minTier || 't1',
      goals: w.goals || [],
      tags: w.tags || [],
      adult: !!w.adult,
      notes: w.notes || [],
      modelCount: wfModels.length,
      models: wfModels.map((m) => m.name),
      nodeTypes: s ? s.nodeTypes : [],
      totalGB: Number(wfModels.reduce((a, m) => a + (m.sizeGB || m.sizeGBEst || 0), 0).toFixed(2)),
      hasUnknownSizes: wfModels.some((m) => m.sizeGB == null && m.sizeGBEst == null),
    };
  })
  .sort((a, b) => a.category.localeCompare(b.category) || a.file.localeCompare(b.file));

// ---------- 6) 组装 plugins.json ----------
const plugins = meta.plugins.plugins.map((p) => ({
  ...p,
  usedByWorkflows: scan && p.provides
    ? [...new Set(Object.entries(scan.nodeTypes).filter(([n]) => p.provides.includes(n)).flatMap(([, ws]) => ws))].sort()
    : [],
}));

const out = {
  generatedFrom: 'workflows/ + catalog/*.meta.json',
  workflowCount: workflows.length,
  modelCount: models.length,
  pluginCount: plugins.length,
  uncoveredNodeTypes: uncovered,
};

if (errors.length) {
  console.error(`✗ 目录校验失败，${errors.length} 处：`);
  for (const e of errors) console.error('  - ' + e);
  process.exit(1);
}
if (warnings.length) for (const w of warnings) console.warn('! ' + w);

if (checkOnly) {
  console.log(
    `✓ 校验通过：工作流 ${out.workflowCount} 份 / 权重 ${out.modelCount} 个 / 插件 ${out.pluginCount} 个 / ` +
      `未被插件覆盖的节点 ${uncovered.length} 个`
  );
  process.exit(0);
}

writeJson(path.join(catDir, 'scan.json'), scan);
writeJson(path.join(catDir, 'models.json'), models);
writeJson(path.join(catDir, 'workflows.json'), workflows);
writeJson(path.join(catDir, 'plugins.json'), plugins);
writeJson(path.join(catDir, 'uncovered-nodes.json'), {
  _note: '工作流里用到、但既不是 ComfyUI 自带、也没有被 plugins.meta.json 任何插件声明的节点类型。多数是整合包里的零散节点，用户导入后看红框即可确认。',
  nodeTypes: uncovered.map((n) => ({ nodeType: n, workflows: scan.nodeTypes[n] })),
});

console.log(
  `✓ 已生成 catalog/：工作流 ${out.workflowCount} 份 / 权重 ${out.modelCount} 个 / 插件 ${out.pluginCount} 个 / ` +
    `未覆盖节点 ${uncovered.length} 个`
);

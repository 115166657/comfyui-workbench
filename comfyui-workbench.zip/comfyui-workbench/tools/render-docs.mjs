#!/usr/bin/env node
/**
 * 从 catalog/ 生成两份对照文档。
 *
 * 为什么不手写：模型表有 49 行、插件表有 21 行，手写的版本一定会和工作流漂移。
 * 这两份 md 的每一行都来自扫描结果 + 注记，改了工作流重跑一次就对上了。
 *
 * 用法：node tools/render-docs.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCatalog, GOALS } from '../server/lib/plan.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const cat = loadCatalog();

const sizeCell = (m) => (m.sizeGB != null ? `${m.sizeGB}` : m.sizeGBEst != null ? `约 ${m.sizeGBEst} *` : '**未知**');
const srcCell = (m) =>
  m.source?.kind === 'hf' ? `[\`${m.source.repo}\`](https://huggingface.co/${m.source.repo})` : '需你搜索';

// ---------- 模型与显存对照表 ----------
const L = [];
L.push('<!-- 本文件由 node tools/render-docs.mjs 生成，不要手改 -->');
L.push('');
L.push('# 模型与显存对照表');
L.push('');
L.push('这张表**不是手抄的**：每一行的文件名、用途、体积、来源，都来自 `workflows/` 里真实出现的引用');
L.push('加上 `catalog/models.meta.json` 里的人工注记，由 `tools/build-catalog.mjs` 双向校验后生成。');
L.push('往 `workflows/` 里加新图、重跑一次，这张表就会变。');
L.push('');
L.push('> 「档位」是最低要求：`t1` = 6~9G 显存、`t2` = 10~15G、`t3` = 16~23G、`t4` = 24G+。');
L.push('> 标 `*` 的体积是按结构推算的估算值，不是实测。');
L.push('');
L.push('## 按存放位置分组');
L.push('');

const bySlot = new Map();
for (const m of cat.models) {
  if (!bySlot.has(m.slot)) bySlot.set(m.slot, []);
  bySlot.get(m.slot).push(m);
}
const slotName = {
  diffusion_models: '扩散主干（models/diffusion_models）',
  checkpoints: '检查点（models/checkpoints）',
  loras: 'LoRA（models/loras）',
  vae: 'VAE（models/vae）',
  text_encoders: '文本/视觉编码器（models/text_encoders）',
  unknown: '由节点自身决定目录',
};
for (const [slot, list] of [...bySlot].sort()) {
  L.push(`### ${slotName[slot] || slot}`);
  L.push('');
  L.push('| 文件名 | 放到 | 体积(GB) | 最低档位 | 用途 | 来源 |');
  L.push('|---|---|---|---|---|---|');
  for (const m of list.sort((a, b) => a.name.localeCompare(b.name))) {
    const dir = m.dir ? `\`models/${m.dir}/\`` : '—';
    const tier = m.minTier ? `t${m.minTier}` : '—';
    const r18 = m.r18 ? ' <sub>18+</sub>' : '';
    L.push(`| \`${m.name}\`${r18} | ${dir} | ${sizeCell(m)} | ${tier} | ${m.role || '—'} | ${srcCell(m)} |`);
  }
  L.push('');
}

const total = cat.models.length;
const known = cat.models.filter((m) => m.sizeGB != null).length;
L.push('## 统计');
L.push('');
L.push(`- 权重条目 **${total}** 个，其中 ${known} 个体积有实测记录，${total - known} 个为估算或未知。`);
L.push(`- 这些文件分散在 ${new Set(cat.models.map((m) => m.dir).filter(Boolean)).size} 个子目录里，**目录名必须与工作流里保存的一字不差**。`);
L.push(`- ⚠️ \`models/LLM/\` 是插件运行时注册的目录，写进 \`extra_model_paths.yaml\` 会被静默丢弃，必须物理放那里。`);
L.push('');
fs.mkdirSync(path.join(root, 'docs'), { recursive: true });
fs.writeFileSync(path.join(root, 'docs', '模型与显存对照表.md'), L.join('\n') + '\n', 'utf8');

// ---------- 插件清单 ----------
const P = [];
P.push('<!-- 本文件由 node tools/render-docs.mjs 生成，不要手改 -->');
P.push('');
P.push('# 插件清单（ComfyUI custom_nodes）');
P.push('');
P.push('这些是 **ComfyUI 的插件**，不是工作台自己的插件。工作台零依赖，不需要装任何东西。');
P.push('');
P.push('`覆盖节点数` 是这个插件在 `workflows/` 里被实际用到的节点类型数量 —— 数字越大，缺了它红框越多。');
P.push('');
P.push('**「地址可靠」= 仓库地址经过核对，可以直接 clone；「需你搜索」= 只知道它提供的节点名，');
P.push('必须让你自己的 agent 先搜到仓库、确认存在，再 clone。**这是刻意的设计：这几批节点随整合包分发，');
P.push('写死一个没核对过的地址比不写更糟。');
P.push('');
P.push('| 插件 | 仓库 | 覆盖节点数 | 分级 | 依赖 pip | 为什么需要 |');
P.push('|---|---|---|---|---|---|');
for (const p of [...cat.plugins].sort((a, b) => b.matchedCount - a.matchedCount || a.id.localeCompare(b.id))) {
  const repo = p.repo ? `[${p.id}](${p.repo})` : '**需你搜索**';
  const conf = p.confidence === 'high' ? '地址可靠' : '需你搜索';
  const pip = (p.pip || []).length ? `\`${(p.pip || []).join(' ')}\`` : '—';
  P.push(`| ${p.id} | ${repo} | ${(p.provides || []).length} | ${p.level} · ${conf} | ${pip} | ${p.why} |`);
}
P.push('');
P.push('## 需要搜索的那些，怎么搜');
P.push('');
for (const p of cat.plugins.filter((x) => !x.repo)) {
  P.push(`### ${p.id}`);
  P.push('');
  P.push(`- 提供的节点：${(p.provides || []).map((n) => `\`${n}\``).join('、')}`);
  P.push(`- 搜索线索：${p.searchHint || '按插件名搜索'}`);
  if (p.note) P.push(`- 注意：${p.note}`);
  P.push('');
}
P.push('## 没被任何插件覆盖的节点');
P.push('');
P.push('工作流里用到、但既不是 ComfyUI 自带、也没有匹配到上面任何插件的节点类型：');
P.push('');
for (const u of cat.uncovered.nodeTypes) P.push(`- \`${u.nodeType}\`（出现在 ${u.workflows.length} 份图里）`);
P.push('');
P.push('多数是整合包里的零散辅助节点，导入工作流后看红框即可确认；');
P.push('用 `/object_info` 的 key 集合与工作流的节点类型求差集，是最可靠的查法。');
P.push('');
fs.writeFileSync(path.join(root, 'docs', '插件清单.md'), P.join('\n') + '\n', 'utf8');

// ---------- 工作流总表 ----------
const W = [];
W.push('<!-- 本文件由 node tools/render-docs.mjs 生成，不要手改 -->');
W.push('');
W.push('# 工作流总表');
W.push('');
W.push(`仓库里共 ${cat.workflows.length} 份工作流：${cat.workflows.filter((w) => w.category === 'ui').length} 份界面可用、`);
W.push(`${cat.workflows.filter((w) => w.category === 'api').length} 份 API 图、`);
W.push(`${cat.workflows.filter((w) => w.category === 'optional-r18').length} 份 18+ 内容。`);
W.push('');
W.push('## 界面可用（向导会按你的档位与目标挑其中几份）');
W.push('');
W.push('| 文件 | 标题 | 目标 | 分级 | 最低档位 | 引用权重 | 体积(GB) |');
W.push('|---|---|---|---|---|---|---|');
for (const w of cat.workflows.filter((x) => x.category === 'ui')) {
  const goals = (w.goals || []).map((g) => GOALS.find((x) => x.id === g)?.label || g).join('、');
  W.push(`| \`${w.file}\` | ${w.title} | ${goals} | ${w.level} | ${w.minTier} | ${w.modelCount} | ${w.hasUnknownSizes ? '含未知' : w.totalGB} |`);
}
W.push('');
W.push('## API 图（给脚本 / 机器人调用，普通使用不用导入）');
W.push('');
W.push('| 文件 | 用途 |');
W.push('|---|---|');
for (const w of cat.workflows.filter((x) => x.category === 'api')) W.push(`| \`${w.file}\` | ${w.purpose || w.title} |`);
W.push('');
W.push('## 18+ 内容（默认不会被安装脚本复制）');
W.push('');
W.push('| 文件 | 标题 | 最低档位 | 引用权重 |');
W.push('|---|---|---|---|');
for (const w of cat.workflows.filter((x) => x.category === 'optional-r18')) W.push(`| \`${w.file}\` | ${w.title} | ${w.minTier} | ${w.modelCount} |`);
W.push('');
W.push('这些图引用了成人内容 LoRA，**仅在用户显式勾选时**才会进入清单，且安装脚本默认不会复制它们。');
W.push('');
W.push('## 目标 → 工作流 的对应关系');
W.push('');
for (const g of GOALS) {
  const hits = cat.workflows.filter((w) => w.category !== 'api' && (w.goals || []).includes(g.id));
  W.push(`- **${g.label}**（\`${g.id}\`）：${hits.map((w) => `\`${w.file}\``).join('、') || '（无）'}`);
}
W.push('');
fs.writeFileSync(path.join(root, 'docs', '工作流总表.md'), W.join('\n') + '\n', 'utf8');

console.log('✓ 已生成 docs/模型与显存对照表.md、docs/插件清单.md、docs/工作流总表.md');

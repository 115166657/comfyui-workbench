#!/usr/bin/env node
/**
 * 前端静态一致性检查：app.js 里用到的每个 id / class 选择器，index.html 里必须真的存在。
 *
 * 为什么值得做：这个前端没有构建步骤，也没有框架兜底 —— id 打错一个字母不会报错，
 * 只会安静地什么都不发生（典型症状：按钮点了没反应）。这类 bug 用静态检查抓最便宜。
 *
 * 用法：node tools/check-dom.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const html = fs.readFileSync(path.join(root, 'web', 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'web', 'app.js'), 'utf8');

const htmlIds = new Set([...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]));
const htmlClasses = new Set(html.match(/class="([^"]+)"/g)?.flatMap((c) => c.replace(/class="|"/g, '').split(/\s+/)) || []);
const htmlAttrs = new Set([...html.matchAll(/\s(data-[a-z-]+)(?:=|\s|>)/g)].map((m) => m[1]));

// 有一部分 DOM 是 app.js 运行时拼出来的（renderGoals / renderSteps）。这些不算缺失，
// 但只认【含 < 的模板串】与 dataset 赋值 —— 否则选择器里出现的 [data-x] 会自己满足自己，检查就白做了。
const runtimeMarkup = [...js.matchAll(/`[^`]*<[^`]*`/g)].map((m) => m[0]).join('\n');
for (const m of runtimeMarkup.matchAll(/class="([^"]+)"/g)) {
  for (const c of m[1].split(/\s+/).filter(Boolean)) htmlClasses.add(c);
}
for (const m of runtimeMarkup.matchAll(/\s(data-[a-z-]+)=/g)) htmlAttrs.add(m[1]);
for (const m of js.matchAll(/\.dataset\.([A-Za-z]+)\s*=/g)) htmlAttrs.add('data-' + m[1].toLowerCase());

const problems = [];

// $('#foo') / $('#foo', ctx) / $$('#foo ...')  —— 只校验第一段 id
for (const m of js.matchAll(/\$\$?\(\s*'([^']+)'/g)) {
  const sel = m[1];
  for (const idm of sel.matchAll(/#([A-Za-z0-9_-]+)/g)) {
    if (!htmlIds.has(idm[1])) problems.push(`app.js 用了 #${idm[1]}，但 index.html 里没有这个 id`);
  }
  // .foo 类选择器：只查我们自己约定在 html 里写死的那些
  for (const cm of sel.matchAll(/\.([A-Za-z0-9_-]+)/g)) {
    const cls = cm[1];
    if (['on', 'hidden', 'done', 'r18', 'primary', 'ghost', 'bad', 'ok'].includes(cls)) continue; // 运行时才加的状态类
    if (!htmlClasses.has(cls)) problems.push(`app.js 用了 .${cls}，但 index.html 里没有这个 class`);
  }
}

// getElementById / querySelector 的直接写法
for (const m of js.matchAll(/getElementById\(\s*'([^']+)'/g)) {
  if (!htmlIds.has(m[1])) problems.push(`app.js getElementById('${m[1]}') 在 html 里不存在`);
}

// 前端引用的 data-* 属性必须在 html 上出现过
for (const m of js.matchAll(/\[(data-[a-z-]+)/g)) {
  if (!htmlAttrs.has(m[1])) problems.push(`app.js 用了属性选择器 [${m[1]}]，但 index.html 里没有任何元素带它`);
}

// 反过来：html 里写死的 id 有没有一个是 js 从没用过的（多半是改代码时漏删）
const usedIds = new Set();
for (const m of js.matchAll(/\$\$?\(\s*'([^']+)'/g)) for (const idm of m[1].matchAll(/#([A-Za-z0-9_-]+)/g)) usedIds.add(idm[1]);
const orphan = [...htmlIds].filter((id) => !usedIds.has(id));
if (orphan.length > 3) problems.push(`index.html 有 ${orphan.length} 个 id 从未被 app.js 使用（可能是改代码时漏删）：${orphan.join(', ')}`);

// 静态资源必须存在
for (const m of html.matchAll(/(?:href|src)="\/([^"]+)"/g)) {
  if (!fs.existsSync(path.join(root, 'web', m[1]))) problems.push(`index.html 引用了不存在的资源：/${m[1]}`);
}

if (problems.length) {
  console.error(`✗ 前端一致性检查发现 ${problems.length} 个问题：`);
  for (const p of problems) console.error('  - ' + p);
  process.exit(1);
}
console.log(`✓ 前端一致性通过：${htmlIds.size} 个 id 全部对得上，静态资源齐全`);

#!/usr/bin/env node
/**
 * 命令行入口。工作台网页版做的是同一件事，这里是为了两件事而存在：
 *  1. 让用户的 agent 能直接跑（agent 更喜欢命令行，不需要开浏览器）；
 *  2. 让这套推荐逻辑可以被测 —— 网页版没法写断言，命令行可以。
 *
 * 用法：
 *   node tools/cli.mjs probe
 *   node tools/cli.mjs plan     --vram 8 --ram 16 --disk 120 --goals video,image
 *   node tools/cli.mjs prompt   --vram 8 --ram 16 --goals video --out agent.md
 *   node tools/cli.mjs install  --comfy "D:\ComfyUI\ComfyUI" [--r18] [--overwrite] [--dry]
 *   node tools/cli.mjs check
 */
import fs from 'node:fs';
import path from 'node:path';
import { probeAll } from '../server/lib/probe.mjs';
import { buildPlan, loadCatalog, GOALS } from '../server/lib/plan.mjs';
import { buildAgentPrompt } from '../server/lib/agent-prompt.mjs';
import { installWorkflows, listInstallable } from '../server/lib/install.mjs';

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const k = a.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) out[k] = true;
      else { out[k] = next; i += 1; }
    } else out._.push(a);
  }
  return out;
}

function profileFromArgs(args) {
  const num = (v, d) => (v === undefined ? d : Number(v));
  return {
    gpuName: typeof args.gpu === 'string' ? args.gpu : null,
    hasNvidia: args.nonvidia ? false : true,
    vramGB: num(args.vram, 8),
    ramGB: num(args.ram, 16),
    diskFreeGB: args.disk !== undefined ? Number(args.disk) : null,
    goals: typeof args.goals === 'string' ? args.goals.split(',').map((s) => s.trim()).filter(Boolean) : ['image'],
    includeR18: !!args.r18,
    comfyPath: typeof args.comfy === 'string' ? args.comfy : null,
    comfyModelsDir: typeof args.comfy === 'string' ? path.join(args.comfy, 'models') : null,
  };
}

const fmtLine = (m) => {
  const size = m.sizeGB != null ? `${m.sizeGB} GB` : m.sizeGBEst != null ? `约${m.sizeGBEst} GB` : '体积未知';
  const dir = m.dir ? `models/${m.dir}/` : '(目录由节点决定)';
  const src = m.source?.kind === 'hf' ? `HF:${m.source.repo}` : '需搜索';
  return `  ${m.name}\n      放到 ${dir} · ${size} · 来源 ${src}`;
};

async function cmdProbe() {
  const env = await probeAll();
  console.log(`操作系统   : ${env.os.platform} ${env.os.release} ${env.os.arch}`);
  console.log(`CPU        : ${env.cpu.model} (${env.cpu.cores} 线程)`);
  console.log(`内存       : ${env.ram.totalGB} GB 总量 / ${env.ram.freeGB} GB 可用`);
  console.log(`显卡       : ${env.gpu ? `${env.gpu.name} · ${env.gpu.vramTotalGB} GB 显存 · 驱动 ${env.gpu.driver}` : `未识别（来源 ${env.gpuSource || '无'}）`}`);
  if (env.gpuNames) console.log(`             WMI 看到的显示适配器：${env.gpuNames.join(' / ')}`);
  console.log(`ComfyUI    : ${env.comfy ? `${env.comfy.path}（${env.comfy.source}）` : '未找到'}`);
  console.log(`ComfyUI 服务: ${env.comfyAlive.alive ? `运行中 :${env.comfyAlive.port}` : `未运行 :${env.comfyAlive.port}`}`);
  console.log(`磁盘剩余   : ${Object.entries(env.disks).map(([d, f]) => `${d} ${f} GB`).join(' · ') || '读取失败'}`);
  console.log(`Node       : ${env.node}`);
}

function cmdPlan(args) {
  const profile = profileFromArgs(args);
  const plan = buildPlan(profile);
  const L = [];
  L.push(`档位：${plan.tier.id} — ${plan.tier.name}`);
  L.push(`依据：${plan.tierReason}`);
  L.push(`说明：${plan.tier.summary}`);
  if (plan.videoEnvelope) {
    const v = plan.videoEnvelope;
    L.push(`视频上限：≤ ${v.maxMegapixels} MP / ≤ ${v.maxSeconds} 秒 / ${v.recommendedSteps} 步（${v.basis}）`);
    if (v.wallSecondsPerClip) L.push(`参考耗时：单条约 ${v.wallSecondsPerClip} 秒`);
  }
  if (plan.warnings.length) {
    L.push('');
    L.push('需要知道的硬约束：');
    for (const w of plan.warnings) L.push(`  ! ${w}`);
  }
  L.push('');
  L.push(`要导入的工作流（${plan.workflows.required.length} 份）：`);
  for (const w of plan.workflows.required) L.push(`  ${w.file}  —— ${w.title}（引用 ${w.modelCount} 个权重）`);
  if (plan.workflows.optional.length) {
    L.push(`可选工作流（${plan.workflows.optional.length} 份）：`);
    for (const w of plan.workflows.optional) L.push(`  ${w.file}  要求 ${w.minTier}`);
  }
  if (plan.workflows.blocked.length) {
    L.push(`档位不够、已剔除：`);
    for (const w of plan.workflows.blocked) L.push(`  ${w.file}  —— ${w.reason}`);
  }
  L.push('');
  L.push(`必装权重（${plan.models.required.length} 个 / ${plan.totals.requiredGB} GB）：`);
  for (const m of plan.models.required) L.push(fmtLine(m));
  if (plan.models.recommended.length) {
    L.push('');
    L.push(`推荐权重（${plan.models.recommended.length} 个 / ${plan.totals.recommendedGB} GB）：`);
    for (const m of plan.models.recommended) L.push(fmtLine(m));
  }
  if (plan.models.r18.length) {
    L.push('');
    L.push(`成人内容相关（${plan.models.r18.length} 个 / ${plan.totals.r18GB} GB）：`);
    for (const m of plan.models.r18) L.push(fmtLine(m));
  }
  L.push('');
  L.push(`插件 —— 必装 ${plan.plugins.required.length} / 推荐 ${plan.plugins.recommended.length}：`);
  for (const p of [...plan.plugins.required, ...plan.plugins.recommended]) {
    L.push(`  [${p.level}] ${p.id}${p.repo ? `  ${p.repo}` : '  (需搜索：' + (p.searchHint || p.id) + ')'}`);
  }
  if (plan.models.alternatives?.length) {
    L.push('');
    L.push('同槽位备选（先别下 —— 等上面那套跑通了再考虑换）：');
    for (const a of plan.models.alternatives) L.push(`  ${a.files.join(' + ')}（${a.totalGB} GB）  ${a.reason}`);
  }
  if (plan.totals.unknownSizeCount) L.push(`\n注意：有 ${plan.totals.unknownSizeCount} 个文件体积未知，磁盘规划按实际为准。`);
  console.log(L.join('\n'));
}

async function cmdPrompt(args) {
  const profile = profileFromArgs(args);
  const plan = buildPlan(profile);
  const md = buildAgentPrompt(profile, plan);
  if (typeof args.out === 'string') {
    fs.writeFileSync(args.out, md, 'utf8');
    console.log(`已写入 ${args.out}（${md.length} 字符）`);
  } else {
    console.log(md);
  }
}

function cmdInstall(args) {
  const comfyPath = typeof args.comfy === 'string' ? args.comfy : null;
  if (!comfyPath) {
    console.error('缺少 --comfy "<ComfyUI 根目录>"');
    process.exit(1);
  }
  const files = listInstallable({ includeR18: !!args.r18, includeApi: false });
  const r = installWorkflows({ comfyPath, files, overwrite: !!args.overwrite, dryRun: !!args.dry });
  if (!r.ok && r.error) {
    console.error('✗ ' + r.error);
    process.exit(1);
  }
  console.log(`目标目录：${r.destDir}`);
  console.log(`${args.dry ? '将复制' : '已复制'} ${r.installed.length} 份：`);
  for (const f of r.installed) console.log(`  ✓ ${f.file}（${(f.bytes / 1024).toFixed(0)} KB）`);
  if (r.skipped.length) {
    console.log(`跳过 ${r.skipped.length} 份：`);
    for (const s of r.skipped) console.log(`  – ${s.file}：${s.reason}`);
  }
  for (const e of r.errors) console.error(`  ✗ ${e.file}：${e.error}`);
  if (r.errors.length) process.exit(1);
}

function cmdCheck() {
  const cat = loadCatalog();
  const problems = [];
  // 1) 每份工作流的必装权重都要有去处
  for (const w of cat.workflows.filter((x) => x.category !== 'api')) {
    for (const name of w.models) {
      const m = cat.models.find((x) => x.name === name);
      if (!m) problems.push(`${w.file} 引用了不在目录里的权重 ${name}`);
      else if (!m.role) problems.push(`${m.name} 没有用途说明（role）`);
      else if (!m.source || (!m.source.repo && !m.source.hint)) problems.push(`${m.name} 没有来源说明`);
    }
  }
  // 2) 插件提供节点里不能有空
  for (const p of cat.plugins) {
    if (!p.why) problems.push(`插件 ${p.id} 没有「为什么需要」说明`);
    if (!p.repo && !p.searchHint) problems.push(`插件 ${p.id} 既没有仓库地址也没有搜索线索`);
  }
  // 3) 每个目标都要有能落地的工作流
  for (const g of GOALS) {
    const hits = cat.workflows.filter((w) => w.category !== 'api' && (w.goals || []).includes(g.id));
    if (!hits.length) problems.push(`目标 ${g.id}（${g.label}）没有任何工作流`);
  }
  if (problems.length) {
    console.error(`✗ 目录自检发现 ${problems.length} 个问题：`);
    for (const p of problems) console.error('  - ' + p);
    process.exit(1);
  }
  console.log(
    `✓ 自检通过：${cat.workflows.filter((w) => w.category !== 'api').length} 份工作流 / ` +
      `${cat.models.length} 个权重 / ${cat.plugins.length} 个插件 / ${GOALS.length} 个目标全部有落地路径`
  );
}

const [, , cmd, ...rest] = process.argv;
const args = parseArgs(rest);
const table = { probe: cmdProbe, plan: cmdPlan, prompt: cmdPrompt, install: cmdInstall, check: cmdCheck };
if (!table[cmd]) {
  console.error('用法：node tools/cli.mjs <probe|plan|prompt|install|check> [选项]');
  process.exit(1);
}
await table[cmd](args);
